/******************************************************************************
* 
* Copyright (c) 2010 Freescale Semiconductor;
* All Rights Reserved                       
*
*******************************************************************************
*
* THIS SOFTWARE IS PROVIDED BY FREESCALE "AS IS" AND ANY EXPRESSED OR 
* IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES 
* OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  
* IN NO EVENT SHALL FREESCALE OR ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
* INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
* SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
* STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING 
* IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF 
* THE POSSIBILITY OF SUCH DAMAGE.
*
***************************************************************************//*!
*
* @file      d4dlcd_ili9341.c
*
* @author    b01119 / B03963
* 
* @version   0.0.9.0
* 
* @date      Oct-17-2013
* 
* @brief     D4D driver - ili9341 lcd driver source c file 
*
******************************************************************************/

#include "d4d.h"            // include of all public items (types, function etc) of D4D driver
#include "common_files/d4d_lldapi.h"     // include non public low level driver interface header file (types, function prototypes, enums etc. )
#include "common_files/d4d_private.h"    // include the private header file that contains perprocessor macros as D4D_MK_STR


// identification string of driver - must be same as name D4DLCD_FUNCTIONS structure + "_ID"
// it is used for enable the code for compilation
#define d4dlcd_ili9341_ID 1


// copilation enable preprocessor condition
// the string d4dlcd_ili9341_ID must be replaced by define created one line up
#if (D4D_MK_STR(D4D_LLD_LCD) == d4dlcd_ili9341_ID)
  
  // include of low level driver heaser file
  // it will be included into wole project only in case that this driver is selected in main D4D configuration file
  #include "low_level_drivers\LCD\lcd_controllers_drivers\ili9341\d4dlcd_ili9341.h"
  #include "low_level_drivers\LCD\lcd_hw_interface\common_drivers\d4dlcdhw_common.h"
  /******************************************************************************
  * Macros 
  ******************************************************************************/

  /******************************************************************************
  * Internal function prototypes 
  ******************************************************************************/

  static unsigned char D4DLCD_Init_Ili9341(void);
  static unsigned char D4DLCD_SetWindow_Ili9341(unsigned short x1, unsigned short y1, unsigned short x2, unsigned short y2);
  static unsigned char D4DLCD_SetOrientation_Ili9341(D4DLCD_ORIENTATION new_orientation);
  static void D4DLCD_Send_PixelColor_Ili9341(D4D_COLOR value) ;
  static D4D_COLOR D4DLCD_Read_Word_Ili9341(void);
  static void D4DLCD_Flush_Ili9341(D4DLCD_FLUSH_MODE mode);
  static unsigned char D4DLCD_DeInit_Ili9341(void);

  /**************************************************************//*!
  *
  * Global variables
  *
  ******************************************************************/
  
  // the main structure that contains low level driver api functions
  // the name fo this structure is used for recognizing of configured low level driver of whole D4D
  // so this name has to be used in main configuration header file of D4D driver to enable this driver
  const D4DLCD_FUNCTIONS d4dlcd_ili9341 = 
  {
    D4DLCD_Init_Ili9341,    
    D4DLCD_SetWindow_Ili9341,
    D4DLCD_SetOrientation_Ili9341,
    D4DLCD_Send_PixelColor_Ili9341,
    D4DLCD_Read_Word_Ili9341,
    D4DLCD_Flush_Ili9341,
    D4DLCD_Delay_ms_Common,
    D4DLCD_DeInit_Ili9341,
  };

  /**************************************************************//*!
  *
  * Local variables
  *
  ******************************************************************/
  static D4DLCD_ORIENTATION d4dlcd_orientation = Portrait;
  /**************************************************************//*!
  *
  * Functions bodies
  *
  ******************************************************************/

   
  //-----------------------------------------------------------------------------
  // FUNCTION:    D4DLCD_Init_Ili9341
  // SCOPE:       Low Level Driver API function
  // DESCRIPTION: The function is used for initialization of this low level driver 
  //              
  // PARAMETERS:  none
  //              
  // RETURNS:     result: 1 - Success
  //                      0 - Failed
  //-----------------------------------------------------------------------------  
  static unsigned char D4DLCD_Init_Ili9341(void)
  {
    if(D4D_LLD_LCD_HW.D4DLCDHW_Init == NULL)
      return 0;
    if(D4D_LLD_LCD_HW.D4DLCDHW_SendDataWord == NULL)
      return 0;
    if(D4D_LLD_LCD_HW.D4DLCDHW_SendCmdWord == NULL)
      return 0;
    if(D4D_LLD_LCD_HW.D4DLCDHW_ReadDataWord == NULL)
      return 0;
    if(D4D_LLD_LCD_HW.D4DLCDHW_ReadCmdWord == NULL)
      return 0;
    if(D4D_LLD_LCD_HW.D4DLCDHW_PinCtl == NULL)
      return 0;
    if(D4D_LLD_LCD_HW.D4DLCDHW_FlushBuffer == NULL)
      return 0;
    if(D4D_LLD_LCD_HW.D4DLCDHW_DeInit == NULL)
      return 0;
    
    
    if(!D4D_LLD_LCD_HW.D4DLCDHW_Init())
      return 0;
    
    (void)D4D_LLD_LCD_HW.D4DLCDHW_PinCtl(D4DLCD_BACKLIGHT_PIN, D4DHW_PIN_SET_1);
    (void)D4D_LLD_LCD_HW.D4DLCDHW_PinCtl(D4DLCD_BACKLIGHT_PIN, D4DHW_PIN_OUT);    

    (void)D4D_LLD_LCD_HW.D4DLCDHW_PinCtl(D4DLCD_RESET_PIN, D4DHW_PIN_SET_0);
    (void)D4D_LLD_LCD_HW.D4DLCDHW_PinCtl(D4DLCD_RESET_PIN, D4DHW_PIN_OUT);            

    D4DLCD_Delay_ms_Common(30); 
    (void)D4D_LLD_LCD_HW.D4DLCDHW_PinCtl(D4DLCD_RESET_PIN, D4DHW_PIN_SET_0);   
    D4DLCD_Delay_ms_Common(10);
    (void)D4D_LLD_LCD_HW.D4DLCDHW_PinCtl(D4DLCD_RESET_PIN, D4DHW_PIN_SET_1);   
    D4DLCD_Delay_ms_Common(120);
    
    
    D4D_LLD_LCD_HW.D4DLCDHW_SendCmdWord(0xCF);
    D4D_LLD_LCD_HW.D4DLCDHW_SendDataWord(0x00);
    D4D_LLD_LCD_HW.D4DLCDHW_SendDataWord(0xD1);
    D4D_LLD_LCD_HW.D4DLCDHW_SendDataWord(0x30);
    
    D4D_LLD_LCD_HW.D4DLCDHW_SendCmdWord(0xED);
    D4D_LLD_LCD_HW.D4DLCDHW_SendDataWord(0x64);
    D4D_LLD_LCD_HW.D4DLCDHW_SendDataWord(0x03);
    D4D_LLD_LCD_HW.D4DLCDHW_SendDataWord(0x12);
    D4D_LLD_LCD_HW.D4DLCDHW_SendDataWord(0x81);
    
    
    D4D_LLD_LCD_HW.D4DLCDHW_SendCmdWord(0xE8);
    D4D_LLD_LCD_HW.D4DLCDHW_SendDataWord(0x85);
    D4D_LLD_LCD_HW.D4DLCDHW_SendDataWord(0x01);
    D4D_LLD_LCD_HW.D4DLCDHW_SendDataWord(0x78);
    
    
    D4D_LLD_LCD_HW.D4DLCDHW_SendCmdWord(0xCB);
    D4D_LLD_LCD_HW.D4DLCDHW_SendDataWord(0x39);
    D4D_LLD_LCD_HW.D4DLCDHW_SendDataWord(0x2C);
    D4D_LLD_LCD_HW.D4DLCDHW_SendDataWord(0X00);
    D4D_LLD_LCD_HW.D4DLCDHW_SendDataWord(0x34);
    D4D_LLD_LCD_HW.D4DLCDHW_SendDataWord(0x02);
    
    D4D_LLD_LCD_HW.D4DLCDHW_SendCmdWord(0xF7);
    D4D_LLD_LCD_HW.D4DLCDHW_SendDataWord(0x20);
    
    D4D_LLD_LCD_HW.D4DLCDHW_SendCmdWord(0xEA);
    D4D_LLD_LCD_HW.D4DLCDHW_SendDataWord(0x00);
    D4D_LLD_LCD_HW.D4DLCDHW_SendDataWord(0x00);
    
    D4D_LLD_LCD_HW.D4DLCDHW_SendCmdWord(0xC0);  //Power control
    D4D_LLD_LCD_HW.D4DLCDHW_SendDataWord(0x16);
    
    D4D_LLD_LCD_HW.D4DLCDHW_SendCmdWord(0xC1);  //Power control
    D4D_LLD_LCD_HW.D4DLCDHW_SendDataWord(0x11);
    
    D4D_LLD_LCD_HW.D4DLCDHW_SendCmdWord(0xC5);  //Vcomh & vcoml control
    D4D_LLD_LCD_HW.D4DLCDHW_SendDataWord(0x2B);
    D4D_LLD_LCD_HW.D4DLCDHW_SendDataWord(0x2C);
    
    D4D_LLD_LCD_HW.D4DLCDHW_SendCmdWord(0xC7);  //vcom adjust control
    D4D_LLD_LCD_HW.D4DLCDHW_SendDataWord(0xC0);
    
    D4D_LLD_LCD_HW.D4DLCDHW_SendCmdWord(0xF6);
    D4D_LLD_LCD_HW.D4DLCDHW_SendDataWord(0x01);
    D4D_LLD_LCD_HW.D4DLCDHW_SendDataWord(0x30);
    D4D_LLD_LCD_HW.D4DLCDHW_SendDataWord(0x00);
    
    D4D_LLD_LCD_HW.D4DLCDHW_SendCmdWord(0xB6);
    D4D_LLD_LCD_HW.D4DLCDHW_SendDataWord(0x0A);
    D4D_LLD_LCD_HW.D4DLCDHW_SendDataWord(0xA2);

    D4D_LLD_LCD_HW.D4DLCDHW_SendCmdWord(0x3A);
    D4D_LLD_LCD_HW.D4DLCDHW_SendDataWord(0x55); // 16 bits por pixel (0x66 - 18 bits)

    D4D_LLD_LCD_HW.D4DLCDHW_SendCmdWord(0xB1);
    D4D_LLD_LCD_HW.D4DLCDHW_SendDataWord(0x00);
    D4D_LLD_LCD_HW.D4DLCDHW_SendDataWord(0x1B);

    D4D_LLD_LCD_HW.D4DLCDHW_SendCmdWord(0xF2);
    D4D_LLD_LCD_HW.D4DLCDHW_SendDataWord(0x00);

    D4D_LLD_LCD_HW.D4DLCDHW_SendCmdWord(0x26);
    D4D_LLD_LCD_HW.D4DLCDHW_SendDataWord(0x01);

    D4D_LLD_LCD_HW.D4DLCDHW_SendCmdWord(0xE0);
    D4D_LLD_LCD_HW.D4DLCDHW_SendDataWord(0x0F);
    D4D_LLD_LCD_HW.D4DLCDHW_SendDataWord(0x2D);
    D4D_LLD_LCD_HW.D4DLCDHW_SendDataWord(0x2A);
    D4D_LLD_LCD_HW.D4DLCDHW_SendDataWord(0x0E);
    D4D_LLD_LCD_HW.D4DLCDHW_SendDataWord(0x11);
    D4D_LLD_LCD_HW.D4DLCDHW_SendDataWord(0x09);
    D4D_LLD_LCD_HW.D4DLCDHW_SendDataWord(0x59);
    D4D_LLD_LCD_HW.D4DLCDHW_SendDataWord(0xB9);
    D4D_LLD_LCD_HW.D4DLCDHW_SendDataWord(0x46);
    D4D_LLD_LCD_HW.D4DLCDHW_SendDataWord(0x0C);
    D4D_LLD_LCD_HW.D4DLCDHW_SendDataWord(0x10);
    D4D_LLD_LCD_HW.D4DLCDHW_SendDataWord(0x03);
    D4D_LLD_LCD_HW.D4DLCDHW_SendDataWord(0x18);
    D4D_LLD_LCD_HW.D4DLCDHW_SendDataWord(0x2A);
    D4D_LLD_LCD_HW.D4DLCDHW_SendDataWord(0x00);

    D4D_LLD_LCD_HW.D4DLCDHW_SendCmdWord(0xE1);// negative  gamma
    D4D_LLD_LCD_HW.D4DLCDHW_SendDataWord(0x00);
    D4D_LLD_LCD_HW.D4DLCDHW_SendDataWord(0x12);
    D4D_LLD_LCD_HW.D4DLCDHW_SendDataWord(0x15);
    D4D_LLD_LCD_HW.D4DLCDHW_SendDataWord(0x01);
    D4D_LLD_LCD_HW.D4DLCDHW_SendDataWord(0x0E);
    D4D_LLD_LCD_HW.D4DLCDHW_SendDataWord(0x06);
    D4D_LLD_LCD_HW.D4DLCDHW_SendDataWord(0x26);
    D4D_LLD_LCD_HW.D4DLCDHW_SendDataWord(0x46);
    D4D_LLD_LCD_HW.D4DLCDHW_SendDataWord(0x39);
    D4D_LLD_LCD_HW.D4DLCDHW_SendDataWord(0x03);
    D4D_LLD_LCD_HW.D4DLCDHW_SendDataWord(0x0F);
    D4D_LLD_LCD_HW.D4DLCDHW_SendDataWord(0x0C);
    D4D_LLD_LCD_HW.D4DLCDHW_SendDataWord(0x27);
    D4D_LLD_LCD_HW.D4DLCDHW_SendDataWord(0x15);
    D4D_LLD_LCD_HW.D4DLCDHW_SendDataWord(0x0F);

    
    D4D_LLD_LCD_HW.D4DLCDHW_SendCmdWord(0x21); // Inversion On
    
    D4DLCD_Delay_ms_Common(50);
    
    D4D_LLD_LCD_HW.D4DLCDHW_SendCmdWord(0x11); // Sleep OUT

    D4DLCD_Delay_ms_Common(120);
    
    D4D_LLD_LCD_HW.D4DLCDHW_SendCmdWord(0x29); //display on
    
    

    return 1;
  }
     
  //-----------------------------------------------------------------------------
  // FUNCTION:    D4DLCD_DeInit_Ili9341
  // SCOPE:       Low Level Driver API function
  // DESCRIPTION: The function is used for deinitialization of this low level driver 
  //              
  // PARAMETERS:  none
  //              
  // RETURNS:     result: 1 - Success
  //                      0 - Failed
   //-----------------------------------------------------------------------------  
  static unsigned char D4DLCD_DeInit_Ili9341(void)
  {
    return 0; 
  }    
  
  //-----------------------------------------------------------------------------
  // FUNCTION:    D4DLCD_SetWindow_Ili9341
  // SCOPE:       Low Level Driver API function
  // DESCRIPTION: The function sets the logic window in memory of LCD driver
  // 
  // PARAMETERS:  unsigned short x1 - left cordination of logic window
  //              unsigned short y1 - top cordination of logic window
  //              unsigned short x2 - right cordination of logic window
  //              unsigned short y2 - bottom cordination of logic window
  //              
  // RETURNS:     result: 1 - Success
  //                      0 - Failed
    //----------------------------------------------------------------------------- 
  static unsigned char D4DLCD_SetWindow_Ili9341(unsigned short x1, unsigned short y1, unsigned short x2, unsigned short y2)
  {
    D4D_LLD_LCD_HW.D4DLCDHW_SendCmdWord(0x2A);  // column select
    D4D_LLD_LCD_HW.D4DLCDHW_SendDataWord((x1 >> 8) & 0xff);
    D4D_LLD_LCD_HW.D4DLCDHW_SendDataWord(x1 & 0xff);
    D4D_LLD_LCD_HW.D4DLCDHW_SendDataWord((x2 >> 8) & 0xff);
    D4D_LLD_LCD_HW.D4DLCDHW_SendDataWord(x2 & 0xff);

    D4D_LLD_LCD_HW.D4DLCDHW_SendCmdWord(0x2B); //page select
    D4D_LLD_LCD_HW.D4DLCDHW_SendDataWord((y1 >> 8) & 0xff);
    D4D_LLD_LCD_HW.D4DLCDHW_SendDataWord(y1 & 0xff);
    D4D_LLD_LCD_HW.D4DLCDHW_SendDataWord((y2 >> 8) & 0xff);
    D4D_LLD_LCD_HW.D4DLCDHW_SendDataWord(y2 & 0xff);
  
    D4D_LLD_LCD_HW.D4DLCDHW_SendCmdWord(0x2C);
    
    return 1;
  }

  //-----------------------------------------------------------------------------
  // FUNCTION:    D4DLCD_SetOrientation_Ili9341
  // SCOPE:       Low Level Driver API function
  // DESCRIPTION: The function set the new orientation of LCD  
  //
  // PARAMETERS:  D4DLCD_ORIENTATION new_orientation    the requested new orientation
  //
  // RETURNS:     result: 1 - Success
  //                      0 - Failed                
  //-----------------------------------------------------------------------------
  static unsigned char D4DLCD_SetOrientation_Ili9341(D4DLCD_ORIENTATION new_orientation)
  {       
    unsigned char MADCTL = 0;
    
    d4dlcd_orientation = new_orientation;
     
    switch (d4dlcd_orientation)
    {
        default: // Invalid! Fall through to portrait mode
        case Portrait:
            MADCTL = 0x08; break;
        case Portrait180:
            MADCTL = 0xC8; break;
        case Landscape:
            MADCTL = 0x68; break;
        case Landscape180:
            MADCTL = 0xA8; break;
    }
    D4D_LLD_LCD_HW.D4DLCDHW_SendCmdWord(0x36);
    D4D_LLD_LCD_HW.D4DLCDHW_SendDataWord(MADCTL);
    
    (void)D4DLCD_SetWindow_Ili9341(0, 0, 1, 1);
    
    return 1;
  }
  
  //-----------------------------------------------------------------------------
  // FUNCTION:    D4DLCD_Send_PixelColor_Ili9341
  // SCOPE:       Low Level Driver API function
  // DESCRIPTION: The function send the one pixel (Word) into LCD  
  //
  // PARAMETERS:  D4D_COLOR Value    value of pixel color
  //
  // RETURNS:     none                
  //-----------------------------------------------------------------------------
  static void D4DLCD_Send_PixelColor_Ili9341(D4D_COLOR value)
  {       
    #ifdef D4D_COLOR_TRANSPARENT
    if(value == D4D_COLOR_TRANSPARENT)
      D4D_LLD_LCD_HW.D4DLCDHW_ReadDataWord();
    else
    #endif
    {
      #if D4D_COLOR_SYSTEM != D4D_COLOR_SYSTEM_RGB565
        Word color = D4D_COLOR_RGB565(D4D_COLOR_GET_R(value), D4D_COLOR_GET_G(value), D4D_COLOR_GET_B(value));
        D4D_LLD_LCD_HW.D4DLCDHW_SendDataWord(color);
      #else
        D4D_LLD_LCD_HW.D4DLCDHW_SendDataWord(value);
      #endif
      
    }
  }
  
  //-----------------------------------------------------------------------------
  // FUNCTION:    D4DLCD_Read_Word_Ili9341
  // SCOPE:       Low Level Driver API function
  // DESCRIPTION: The function reads the one Word(Pixel) from LCD (if this function is supported)  
  //
  // PARAMETERS:  none
  //
  // RETURNS:     unsigned short - the readed value
  //              
  //-----------------------------------------------------------------------------
  static D4D_COLOR D4DLCD_Read_Word_Ili9341(void)
  {       
    #if D4D_COLOR_SYSTEM != D4D_COLOR_SYSTEM_RGB565
      Word color =  D4D_LLD_LCD_HW.D4DLCDHW_ReadDataWord();
      return D4D_COLOR_RGB(D4D_COLOR565_GET_R(color), D4D_COLOR565_GET_G(color), D4D_COLOR565_GET_B(color));
    #else
      return D4D_LLD_LCD_HW.D4DLCDHW_ReadDataWord();
    #endif
  }
  

  
  //-----------------------------------------------------------------------------
  // FUNCTION:    D4DLCD_Flush_Ili9341
  // SCOPE:       Low Level Driver API function
  // DESCRIPTION: For buffered low level interfaces is used to inform
  //              driver the complete object is drawed and pending pixels should be flushed
  //
  // PARAMETERS:  mode - mode of Flush
  //              
  // RETURNS:     none
  //-----------------------------------------------------------------------------
  static void D4DLCD_Flush_Ili9341(D4DLCD_FLUSH_MODE mode)
  {       
    D4D_LLD_LCD_HW.D4DLCDHW_FlushBuffer(mode);
  }


#endif //(D4D_MK_STR(D4D_LLD_LCD) == d4dlcd_ili9341_ID)