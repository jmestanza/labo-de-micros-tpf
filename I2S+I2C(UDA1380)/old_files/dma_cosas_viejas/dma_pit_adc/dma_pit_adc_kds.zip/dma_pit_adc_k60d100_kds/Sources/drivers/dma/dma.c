/*
 * dma.c
 *
 *  Created on: Nov 25, 2014
 *      Author: Manuel Alejandro
 */
#include "dma.h"

/*	dma_init()
 * Initializes the DMA module to read the ADC results every time a conversion has
 * finished and stores its value in a buffer
 * 
 * */
void dma_init(void)
{
	// Enable clock for DMAMUX and DMA
	SIM->SCGC6 |= SIM_SCGC6_DMAMUX_MASK;
	SIM->SCGC7 |= SIM_SCGC7_DMA_MASK;
			
	// Enable Channel 0 and set ADC1 as DMA request source 
	DMAMUX->CHCFG[0] |= DMAMUX_CHCFG_ENBL_MASK | DMAMUX_CHCFG_SOURCE(41);

	// Enable request signal for channel 0 
	DMA0->ERQ = DMA_ERQ_ERQ0_MASK;
		
	// Set memory address for source and destination 
	DMA0->TCD[0].SADDR = (uint32_t)&ADC1->R[0];
	DMA0->TCD[0].DADDR = (uint32_t)&value;

	// Set an offset for source and destination address
	DMA0->TCD[0].SOFF = 0x00; // Source address offset of 2 bits per transaction
	DMA0->TCD[0].DOFF = 0x02; // Destination address offset of 1 bit per transaction
		
	// Set source and destination data transfer size
	DMA0->TCD[0].ATTR = DMA_ATTR_SSIZE(1) | DMA_ATTR_DSIZE(1);
		
	// Number of bytes to be transfered in each service request of the channel
	DMA0->TCD[0].NBYTES_MLNO = 0x02;
		
	// Current major iteration count (a single iteration of 5 bytes)
	DMA0->TCD[0].CITER_ELINKNO = DMA_CITER_ELINKNO_CITER(ADC_READS);
	DMA0->TCD[0].BITER_ELINKNO = DMA_BITER_ELINKNO_BITER(ADC_READS);
	
	// Adjustment value used to restore the source and destiny address to the initial value
	DMA0->TCD[0].SLAST = 0x00;		// Source address adjustment
	DMA0->TCD[0].DLAST_SGA = -0x10;	// Destination address adjustment
	
	// Setup control and status register
	DMA0->TCD[0].CSR = 0;
}
