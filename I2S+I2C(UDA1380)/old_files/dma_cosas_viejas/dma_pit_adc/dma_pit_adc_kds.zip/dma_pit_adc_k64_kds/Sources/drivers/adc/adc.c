/*
 * adc.c
 *
 *  Created on: Nov 25, 2014
 *      Author: Manuel Alejandro
 */

#include "adc.h"

/*	adc_init()
 * Calibrates and initializes adc to perform single conversions and generate
 * DMA requests at the end of the conversion
 * 
 * */
void adc_init(void)
{
	// Enable clocks
	SIM->SCGC6 |= SIM_SCGC6_ADC0_MASK;	// ADC 0 clock
	SIM->SCGC5 |= SIM_SCGC5_PORTB_MASK;	// PTB0 clock
	
	// Calibrate ADC
	adc_cal();

	// Configure ADC
	ADC0->CFG1 = 0; // Reset register
	ADC0->CFG1 |= (ADC_CFG1_MODE(3)  |  	// 16 bits mode
				  ADC_CFG1_ADICLK(0)|	// Input Bus Clock (20-25 MHz out of reset (FEI mode))
				  ADC_CFG1_ADIV(1)) ;	// Clock divide by 2 (10-12.5 MHz)
	
	ADC0->SC2 |= ADC_SC2_DMAEN_MASK;    // DMA Enable
	
	ADC0->SC3 = 0; // Reset SC3
	
	ADC0_SC1A |= ADC_SC1_ADCH(31); // Disable module
}

/* adc_cal
 * Calibrates the adc
 * Returns 0 if successful calibration
 * Returns 1 otherwise
 * */
int adc_cal(void)
{
	ADC0->CFG1 |= (ADC_CFG1_MODE(3)  |  	// 16 bits mode
				  ADC_CFG1_ADICLK(1)|	// Input Bus Clock divided by 2 (20-25 MHz out of reset (FEI mode) / 2)
				  ADC_CFG1_ADIV(2)) ;	// Clock divide by 4 (2.5-3 MHz)
	
	ADC0->SC3 |= ADC_SC3_AVGE_MASK |		// Enable HW average
				ADC_SC3_AVGS(3)   |		// Set HW average of 32 samples
				ADC_SC3_CAL_MASK;		// Start calibration process
	
	while(ADC0->SC3 & ADC_SC3_CAL_MASK); // Wait for calibration to end
	
	if(ADC0->SC3 & ADC_SC3_CALF_MASK)	// Check for successful calibration
		return 1; 
	
	uint16_t calib = 0; // calibration variable 
	calib += ADC0->CLPS + ADC0->CLP4 + ADC0->CLP3 +
			 ADC0->CLP2 + ADC0->CLP1 + ADC0->CLP0;
	calib /= 2;
	calib |= 0x8000; 	// Set MSB 
	ADC0->PG = calib;
	calib = 0;
	calib += ADC0->CLMS + ADC0->CLM4 + ADC0->CLM3 +
			 ADC0->CLM2 + ADC0->CLM1 + ADC0->CLM0;
	calib /= 2;
	calib |= 0x8000;	// Set MSB
	ADC0->MG = calib;
	
	return 0;
}

/*unsigned short	adc_read(unsigned char ch)
 * 	Reads the specified adc channel and returns the 16 bits read value
 * 	
 * 	ch -> Number of the channel in which the reading will be performed
 * 	Returns the -> Result of the conversion performed by the adc
 * 
 * */
unsigned short adc_read(unsigned char ch)
{
	ADC0_SC1A = (ch & ADC_SC1_ADCH_MASK) |
				(ADC0_SC1A & (ADC_SC1_AIEN_MASK | ADC_SC1_DIFF_MASK));     // Write to SC1A to start conversion
	while(ADC0_SC2 & ADC_SC2_ADACT_MASK); 	 // Conversion in progress
	while(!(ADC0_SC1A & ADC_SC1_COCO_MASK)); // Run until the conversion is complete
	return ADC0->R[1];
}
