/*
 * The Clear BSD License
 * Copyright (c) 2017, NXP Semiconductors, Inc.
* All rights reserved.
*
 *
 * Redistribution and use in source and binary forms, with or without modification,
* are permitted (subject to the limitations in the disclaimer below) provided
 * that the following conditions are met:
*
* o Redistributions of source code must retain the above copyright notice, this list
*   of conditions and the following disclaimer.
*
* o Redistributions in binary form must reproduce the above copyright notice, this
*   list of conditions and the following disclaimer in the documentation and/or
*   other materials provided with the distribution.
*
* o Neither the name of the copyright holder nor the names of its
*   contributors may be used to endorse or promote products derived from this
*   software without specific prior written permission.
*
* NO EXPRESS OR IMPLIED LICENSES TO ANY PARTY'S PATENT RIGHTS ARE GRANTED BY THIS LICENSE.
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
* ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
* ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
* ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
* SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#include "gui_driver.h"
#include "fsl_uart.h"
//#include "uart_kw40_transfer.h"
#include <stdio.h>
#include "screens_resources.h"
#include "string.h"

extern volatile bool txOnGoing;
extern uart_handle_t g_uartHandle;
uint8_t g_image[GUI_IMAGE_SIZE]; // OLED buffer screen

/**
 * update the main screen buffer
 * with the given image
 */
void GuiDriver_UpdateScreen(uint8_t xCrd,
                            uint8_t yCrd,

                            uint8_t width,
                            uint8_t height,

                            const uint8_t *image)
{
    // copy data
    oled_pixel_t copyAddr = (oled_pixel_t)g_image + (yCrd * OLED_SCREEN_WIDTH + xCrd);

    for (uint8_t i = 0; i < height; i++)
    {
        memcpy((void *)copyAddr, (void *)image, width * OLED_BYTES_PER_PIXEL);
        copyAddr += OLED_SCREEN_WIDTH;
        image += width * OLED_BYTES_PER_PIXEL;
    }
}

/**
 * [GuiDriver_LabelCreate description]
 * @param label [description]
 */
status_t GuiDriver_LabelCreate(guiLabel_t *label)
{
    if (label->caption != NULL)
    {
        return kStatus_Fail;
    }

    label->caption = (uint8_t *)malloc(label->captionLength);

    if (label->caption != NULL)
    {
        return kStatus_Success;
    }
    else
    {
        return kStatus_Fail;
    }
}

/**
 * [GuiDriver_LabelDestroy description]
 * @param label [description]
 */
status_t GuiDriver_LabelDestroy(guiLabel_t *label)
{
    if (label->caption != NULL)
    {
        free(label->caption);
        label->caption = NULL;
        return kStatus_Success;
    }

    return kStatus_Fail;
}

/**
 * [GuiDriver_LabelSetCaption description]
 * @param label [description]
 * @param caption [description]
 * @param length [description]
 */
void GuiDriver_LabelSetCaption(guiLabel_t *label, uint8_t *caption)
{
    strcpy((char *)label->caption, (char *)caption);
}

/**
 * [GuiDriver_LabelFormatCaption description]
 * @param label [description]
 * @param caption [description]
 * @param length [description]
 * @param format [description]
 */
status_t GuiDriver_LabelFormatCaption(guiLabel_t *label, uint8_t *caption, uint8_t *length, guiLabelCutFormat_t format)
{
    uint8_t tmpLength;
    uint8_t inLength;

    if (length == NULL)
    {
        inLength = strlen((char *)caption);
    }
    else
    {
        inLength = *length;
    }

    if (inLength > (label->captionLength - 1))
    {
        tmpLength = label->captionLength - 1;
    }
    else
    {
        tmpLength = inLength;
    }

    tmpLength = OLED_CharCount(label->dynamicArea.width, label->textProperties.font, caption, tmpLength);
    if (tmpLength == 0)
    {
        return kStatus_Fail;
    }

    memcpy(label->caption, caption, tmpLength);
    label->caption[tmpLength] = 0;

    if (tmpLength < inLength)
    {
        if (format == GUI_LABEL_CUT_FORMAT_DOTS)
        {
            if (tmpLength <= 2)
            {
                return kStatus_Fail;
            }

            label->caption[tmpLength - 1] = '.';
            label->caption[tmpLength - 2] = '.';
            tmpLength -= 2;
        }
        else if (format == GUI_LABEL_CUT_FORMAT_SPACE)
        {
            char *tmpPtr;
            tmpPtr = strrchr((char *)label->caption, ' ');
            if ((tmpPtr != NULL) && (tmpPtr != (char *)label->caption))
            {
                *tmpPtr = 0;
                tmpLength = tmpPtr - (char *)label->caption;
            }
        }
    }

    if (length != NULL)
    {
        *length = tmpLength;
    }

    return kStatus_Success;
}

/**
 * [GuiDriver_LabelDraw description]
 * @param label [description]
 */
void GuiDriver_LabelDraw(guiLabel_t *label)
{
    OLED_SetTextProperties(&label->textProperties);
    OLED_SetDynamicArea(&label->dynamicArea);
    while (1)
    {
        if (OLED_STATUS_SUCCESS == OLED_DrawText(label->caption))
        {
            break;
        }
    }
}

/**
 * [GuiDriver_AddToScrLabel description]
 * @param label [description]
 */
void GuiDriver_LabelAddToScr(guiLabel_t *label)
{
    OLED_SetTextProperties(&label->textProperties);
    OLED_SetDynamicArea(&label->dynamicArea);
    OLED_AddText(label->caption);
}

/**
 * [GuiDriver_ImageDraw description]
 * @param image [description]
 */

void GuiDriver_ImageDraw(guiImage_t *image)
{
    OLED_GetImageDimensions(&image->dynamicArea.width, &image->dynamicArea.height, image->img);
    OLED_SetDynamicArea(&image->dynamicArea);
    while (1)
    {
        if (OLED_STATUS_SUCCESS == OLED_DrawImage(image->img))
        {
            break;
        }
    }
}

/**
 * [GuiDriver_AddToScrImage description]
 * @param image [description]
 */
void GuiDriver_ImageAddToScr(guiImage_t *image)
{
    OLED_GetImageDimensions(&image->dynamicArea.width, &image->dynamicArea.height, image->img);
    OLED_SetDynamicArea(&image->dynamicArea);
    OLED_AddImage(image->img);
    GuiDriver_UpdateScreen(image->dynamicArea.xCrd, image->dynamicArea.yCrd, image->dynamicArea.width,
                           image->dynamicArea.height, (const uint8_t *)image->dynamicArea.areaBuffer);
}

/**
 * [GuiDriver_ClearScr description]
 */
void GuiDriver_ClearScr(void)
{
    memset(g_image, 0, OLED_SCREEN_WIDTH * OLED_SCREEN_HEIGHT * OLED_BYTES_PER_PIXEL);
    OLED_FillScreen(0);
}

/**
 * [GuiDriver_CleanMainArea description]
 */
void GuiDriver_CleanMainArea()
{
    while (OLED_STATUS_SUCCESS != OLED_DrawBox(0, 20, 90, 55, 0x0))
    {
    }
}

/**
 * [GuiDriver_CleanMainArea description]
 */
void GuiDriver_CleanAbout()
{
    while (OLED_STATUS_SUCCESS != OLED_DrawBox(0, 0, 90, 80, 0x0))
    {
    }
}
#if 0
/**
 * notify KW40 which app is being runned currently
 * @param  currentApp current app descriptor
 * @return            [description]
 */
status_t GuiDriver_NotifyKW40(uint32_t currentApp)
{
    uart_transfer_t xfer; 

    hostInterface_packet_t
        currentAppPacket =
        {
            .type   = packetType_appMode,
            .length = sizeof(currentApp)
        };

    memcpy( (void*)&(currentAppPacket.data[0]), (void*)&currentApp, sizeof(currentApp) );
    currentAppPacket.data[ currentAppPacket.length ] = gHostInterface_trailerByte;
    currentAppPacket.start1 = gHostInterface_startByte1;
    currentAppPacket.start2 = gHostInterface_startByte2|0x1;

    /* Send data out. */
    xfer.data =  (uint8_t *)&currentAppPacket;
    xfer.dataSize = sizeof(currentAppPacket);
    //txOnGoing = true;
    UART_TransferSendNonBlocking(BOARD_KW40_UART_BASEADDR, &g_uartHandle, &xfer);

    /* Wait send finished */
    while (txOnGoing)
    {
    }
    
    return kStatus_Success;
}
#endif
