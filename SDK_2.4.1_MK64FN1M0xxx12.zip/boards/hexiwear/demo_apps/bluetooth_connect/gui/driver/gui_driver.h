/*
 * The Clear BSD License
 * Copyright (c) 2017, NXP Semiconductors, Inc.
* All rights reserved.
*
 *
 * Redistribution and use in source and binary forms, with or without modification,
* are permitted (subject to the limitations in the disclaimer below) provided
 * that the following conditions are met:
*
* o Redistributions of source code must retain the above copyright notice, this list
*   of conditions and the following disclaimer.
*
* o Redistributions in binary form must reproduce the above copyright notice, this
*   list of conditions and the following disclaimer in the documentation and/or
*   other materials provided with the distribution.
*
* o Neither the name of the copyright holder nor the names of its
*   contributors may be used to endorse or promote products derived from this
*   software without specific prior written permission.
*
* NO EXPRESS OR IMPLIED LICENSES TO ANY PARTY'S PATENT RIGHTS ARE GRANTED BY THIS LICENSE.
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
* ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
* ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
* ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
* SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#ifndef _GUI_DRIVER_H_
#define _GUI_DRIVER_H_

#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include "fsl_common.h"
#include "fsl_psp27801.h"
#include "gui_resources.h"

typedef struct
{
    oled_dynamic_area_t dynamicArea;
    oled_text_properties_t textProperties;
    uint8_t *caption;
    uint8_t captionLength;
} guiLabel_t;

typedef enum {
    GUI_LABEL_CUT_FORMAT_NONE = 0,
    GUI_LABEL_CUT_FORMAT_DOTS = 1,
    GUI_LABEL_CUT_FORMAT_SPACE = 2
} guiLabelCutFormat_t;

typedef struct
{
    oled_dynamic_area_t dynamicArea;
    const uint8_t *img;
} guiImage_t;

void GuiDriver_UpdateScreen(uint8_t xCrd,
                            uint8_t yCrd,

                            uint8_t width,
                            uint8_t height,

                            const uint8_t *image);

/**
 * [GuiDriver_LabelCreate description]
 * @param label [description]
 */
status_t GuiDriver_LabelCreate(guiLabel_t *label);

/**
 * [GuiDriver_LabelDestroy description]
 * @param label [description]
 */
status_t GuiDriver_LabelDestroy(guiLabel_t *label);

/**
 * [GuiDriver_LabelDraw description]
 * @param label [description]
 * @param caption [description]
 * @param length [description]
 */
void GuiDriver_LabelSetCaption(guiLabel_t *label, uint8_t *caption);

/**
 * [GuiDriver_LabelFormatCaption description]
 * @param label [description]
 * @param caption [description]
 * @param length [description]
 * @param format [description]
 */
status_t GuiDriver_LabelFormatCaption(guiLabel_t *label, uint8_t *caption, uint8_t *length, guiLabelCutFormat_t format);

/**
 * [GuiDriver_LabelDraw description]
 * @param label [description]
 */
void GuiDriver_LabelDraw(guiLabel_t *label);

/**
 * [GuiDriver_LabelAddToScr description]
 * @param label [description]
 */
void GuiDriver_LabelAddToScr(guiLabel_t *label);

/**
 * [GuiDriver_ImageDraw description]
 * @param image [description]
 */
void GuiDriver_ImageDraw(guiImage_t *image);

/**
 * [GuiDriver_ImageAddToScr description]
 * @param image [description]
 */
void GuiDriver_ImageAddToScr(guiImage_t *image);

/**
 * [GuiDriver_DrawButtonPointers description]
 * @param upButtonFlag [description]
 * @param downButtonFlag [description]
 */
void GuiDriver_DrawButtonPointers(bool upButtonFlag, bool downButtonFlag);

/**
 * [GuiDriver_ClearScr description]
 * @param color [description]
 */

void GuiDriver_ClearScr(void);

/**
 * [GuiDriver_RegisterForSensor description]
 * @param packetToReceive [description]
 */
void GuiDriver_RegisterMinPollDelay(uint32_t delay);

/**
 * [GuiDriver_CleanMainArea description]
 */
void GuiDriver_CleanMainArea(void);

/**
 * notify KW40 which app is being runned currently
 * @param  currentApp current app descriptor
 * @return            [description]
 */
status_t GuiDriver_NotifyKW40(uint32_t currentApp);

/**
 * [GuiDriver_CleanMainArea description]
 */
void GuiDriver_CleanAbout(void);

#endif /* _GUI_DRIVER_H_ */
