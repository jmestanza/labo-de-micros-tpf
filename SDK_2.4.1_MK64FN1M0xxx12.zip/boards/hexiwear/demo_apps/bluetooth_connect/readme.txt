Overview
========
The hexiwear bluetooth connectivity demo application provides a simple demo for users to use the hexiwear to connect to the mobile phone with blue tooth.
Before run the demo, please install "BLE Reader" APP on your mobile phone.
This demo shows how the mobile phone transmit notification data to hexiwear and hexiwear
print the notification on debug console on it's host mcu K64.
First, user should press the right button on the main board to open the blue tooth.
Then, search device named "HEXIWEAR" on your phone and connect to it with the key show on the hexiwear watch screen.
Open the BLE Reader on your mobile phone and choose the HEXIWEAR device on BLE Reader list.
Enter Alert/command Service with write attribute:
Unkown
00002030-0000-1000-8000-00805F9B34FB
Enter the Alert in with UUID 0x2031 and  write a new data with 20-byte length following the message requirement. 
Then you will see the alert message received and print on the debug console.

Toolchain supported
===================
- Keil MDK 5.24a
- IAR embedded Workbench 8.22.2
- GCC ARM Embedded 7-2017-q4-major
- MCUXpresso10.2.0

Hardware requirements
=====================
- Mini/micro USB cable
- Hexiwear main board
- Personal Computer

Board settings
==============
No special settings are required.

Prepare the Demo
================
1.  Connect a USB cable between the host PC and the OpenSDA USB port on the target board.
2.  Open a serial terminal with the following settings:
    - 115200 baud rate
    - 8 data bits
    - No parity
    - One stop bit
    - No flow control
3.  Download the program to the target board.
4.  Either press the reset button on your board or launch the debugger in your IDE to begin running the demo.
5. Press the right button on the main board to open the blue tooth. Search device named "HEXIWEAR" on your phone and connect to it with the key show on the hexiwear watch screen.

Running the demo
================
Open the BLE Reader on your mobile phone and choose the HEXIWEAR device on BLE Reader list. Enter Alert/command Service with write attribute:
Unkown
00002030-0000-1000-8000-00805F9B34FB
Enter the Alert in with UUID 0x2031 and write a new data with 20-byte length following the message requirement. such as if you enter 
0102030405xxxxxxxxxxxxxxxxxxxxxxxxxxxx01

When the demo runs successfully, you can see the information below printed to the terminal. 

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
This is hexiwear bluetooth connectivity demo!

Click the right button of the hexiwear to open/close the bluetooth.


Notification: 3 Unread message from CALL 

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Customization options
=====================

