/*
 * The Clear BSD License
 * Copyright (c) 2017, NXP Semiconductors, Inc.
* All rights reserved.
*
 *
 * Redistribution and use in source and binary forms, with or without modification,
* are permitted (subject to the limitations in the disclaimer below) provided
 * that the following conditions are met:
*
* o Redistributions of source code must retain the above copyright notice, this list
*   of conditions and the following disclaimer.
*
* o Redistributions in binary form must reproduce the above copyright notice, this
*   list of conditions and the following disclaimer in the documentation and/or
*   other materials provided with the distribution.
*
* o Neither the name of the copyright holder nor the names of its
*   contributors may be used to endorse or promote products derived from this
*   software without specific prior written permission.
*
* NO EXPRESS OR IMPLIED LICENSES TO ANY PARTY'S PATENT RIGHTS ARE GRANTED BY THIS LICENSE.
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
* ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
* ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
* ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
* SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#include "board.h"
#include "bond.h"
#include "clock_config.h"
#include "fsl_debug_console.h"
#include "fsl_device_registers.h"
#include "fsl_psp27801.h"
#include "gui_driver.h"
#include "notifications_driver.h"
#include "pin_mux.h"
#include "screens_resources.h"
#include "uart_kw40_transfer.h"

#include "fsl_common.h"
#include "fsl_gpio.h"
#include "fsl_port.h"
/*******************************************************************************
 * Definitions
 ******************************************************************************/

/*******************************************************************************
 * Prototypes
 ******************************************************************************/

/*******************************************************************************
 * Variables
 ******************************************************************************/
extern volatile touch_type_t pressedTouch;
extern uart_handle_t g_uartHandle;
oled_dynamic_area_t splashArea = {.xCrd = 0, .yCrd = 0};
guiImage_t bluetooth_icon = {.dynamicArea = {.xCrd = 24, .yCrd = 23}, .img = bluetooth_icon_blue_bmp};
extern volatile bool g_bleAdvEnable;
extern volatile bool g_bondKeySet;
extern guiLabel_t bond_label;
extern volatile bool g_Notification;
extern volatile uint8_t g_RxNotificationData[3];
/*******************************************************************************
 * Code
 ******************************************************************************/

void Bluetooth_SendToggleAdvModeReq(void)
{
    uart_transfer_t xfer;

    static hostInterface_packet_t dataPacket = {.start1 = gHostInterface_startByte1,
                                                .start2 = gHostInterface_startByte2 | 0x1,
                                                .length = 0,
                                                .data[0] = gHostInterface_trailerByte};

    dataPacket.type = packetType_advModeToggle;

    /* Send data out. */
    xfer.data = (uint8_t *)&dataPacket;
    xfer.dataSize = sizeof(dataPacket);
    while (UART_TransferSendNonBlocking(BOARD_KW40_UART_BASEADDR, &g_uartHandle, &xfer) != kStatus_Success)
        ;
}

void Bluetooth_SendGetAdvModeReq(void)
{
    uart_transfer_t xfer;

    static hostInterface_packet_t dataPacket = {.start1 = gHostInterface_startByte1,
                                                .start2 = gHostInterface_startByte2 | 0x1,
                                                .length = 0,
                                                .data[0] = gHostInterface_trailerByte};

    dataPacket.type = packetType_advModeGet;
    /* Send data out. */
    xfer.data = (uint8_t *)&dataPacket;
    xfer.dataSize = sizeof(dataPacket);
    while (UART_TransferSendNonBlocking(BOARD_KW40_UART_BASEADDR, &g_uartHandle, &xfer) != kStatus_Success)
        ;
}
/*!
 * @brief Main function
 */
int main(void)
{
    BOARD_InitPins();
    BOARD_BootClockRUN();
    BOARD_InitDebugConsole();
    /* Initialize the timer for delay function */
    Timer_Init();
    /* Initialize the KW40 */
    KW40_UART_Init();

    PRINTF("This is hexiwear bluetooth connectivity demo!\r\n");

    /* Initialize the GPIO and DSPI for OLED transfer */
    OLED_Hardware_Init();
    /* Initialize the OLED and set the dynamic area */
    OLED_Init();
    /* Initialize bluetooth GUI. */
    OLED_GetImageDimensions(&(splashArea.width), &(splashArea.height), bluetooth_screen_bmp);
    OLED_DrawScreen(&bluetooth_screen_bmp[6], splashArea.xCrd, splashArea.yCrd, splashArea.width, splashArea.height,
                    kOLED_Transition_None);
    bluetooth_icon.img = bluetooth_icon_white_bmp;
    GuiDriver_ImageAddToScr(&bluetooth_icon);
    GuiDriver_ImageDraw(&bluetooth_icon);

    /* First Close the ble adv */
    Bluetooth_SendGetAdvModeReq();
    Timer_Delay_ms(500);
    if (g_bleAdvEnable)
    {
        Bluetooth_SendToggleAdvModeReq();
        Timer_Delay_ms(500);
    }

    PRINTF("\r\nClick the right button of the hexiwear to open/close the bluetooth.\r\n\r\n");

    while (1)
    {
        if (pressedTouch == touch_right)
        {
            Bluetooth_SendToggleAdvModeReq();
            Timer_Delay_ms(100);

            /* Update status */
            if (g_bleAdvEnable)
            {
                bluetooth_icon.img = bluetooth_icon_blue_bmp;
            }
            else
            {
                bluetooth_icon.img = bluetooth_icon_white_bmp;
            }
            OLED_GetImageDimensions(&(splashArea.width), &(splashArea.height), bluetooth_screen_bmp);
            OLED_DrawScreen(&bluetooth_screen_bmp[6], splashArea.xCrd, splashArea.yCrd, splashArea.width,
                            splashArea.height, kOLED_Transition_None);
            GuiDriver_ImageDraw(&bluetooth_icon);
        }

        /* Bond info */
        if (g_bondKeySet)
        {
            uint32_t passkey = 0;
            uint8_t xCrd = 0;
            uint8_t yCrd = 0;
            uint8_t width;
            uint8_t height;

            memcpy((uint8_t *)&passkey, (uint8_t *)&g_RxNotificationData[0], 3);
            Bond_SetPasskey(passkey);
            Bond_Init();
            OLED_GetImageDimensions(&width, &height, bond_screen_bmp);
            OLED_DrawScreen(&bond_screen_bmp[6], xCrd, yCrd, width, height, kOLED_Transition_Right_Left);
            GuiDriver_LabelDraw(&bond_label);
            g_bondKeySet = false;
        }

        /* Notification check*/
        if (g_Notification)
        {
            notification_type_t notifType = NOTIF_TYPE_SMS;
            uint8_t notifCnt = g_RxNotificationData[2];
            ancCategoryId_t categoryID = (ancCategoryId_t)g_RxNotificationData[1];

            if (g_RxNotificationData[0] == alertIn_type_notification)
            {
                switch (categoryID)
                {
                    case ancCategoryId_missedCall:
                    {
                        notifType = NOTIF_TYPE_CALL;
                        break;
                    }
                    case ancCategoryId_email:
                    {
                        notifType = NOTIF_TYPE_MAIL;
                        break;
                    }
                    case ancCategoryId_social:
                    {
                        notifType = NOTIF_TYPE_SMS;
                        break;
                    }

                    default:
                    {
                        break;
                    }
                }

                notifCnt += Notification_GetUnreadCounter(notifType);
                Notification_SetUnreadCounter(notifType, notifCnt);

                notifCnt = Notification_GetUnreadCounter(NOTIF_TYPE_CALL);
                if (notifCnt)
                {
                    PRINTF("\r\nNotification: %d Unread message from CALL \r\n", notifCnt);
                }
                notifCnt = Notification_GetUnreadCounter(NOTIF_TYPE_MAIL);
                if (notifCnt)
                {
                    PRINTF("\r\nNotification: %d Unread message from MAIL \r\n", notifCnt);
                }
                notifCnt = Notification_GetUnreadCounter(NOTIF_TYPE_SMS);
                if (notifCnt)
                {
                    PRINTF("\r\nNotification: %d Unread message from SMS \r\n", notifCnt);
                }
                g_Notification = false;
            }
        }
    }
}
