#include <stdint.h>
#include "board.h"
#include "fsl_i2c.h"
#include "fsl_port.h"
#include "fsl_gpio.h"
#include "fsl_timer.h"
#include <tool.h>


/*! @brief Type for an semaphore */
typedef struct Semaphore
{
    volatile bool    isWaiting;  /*!< Is any task waiting for a timeout on this object */
    volatile uint8_t semCount;   /*!< The count value of the object                    */
    uint32_t         time_start; /*!< The time to start timeout                        */
    uint32_t         timeout;    /*!< Timeout to wait in milliseconds                  */
} semaphore_t;

semaphore_t IrqSem;
i2c_master_transfer_t masterXfer;

typedef enum {ERROR = 0, SUCCESS = !ERROR} Status;

void PORTB_IRQHandler(void)
{
  uint32_t irqmask;
  
      if (GPIO_PinRead(BOARD_NXPNCI_IRQ_GPIO, BOARD_NXPNCI_IRQ_PIN) == 1)
      {
      GPIO_PortClearInterruptFlags(BOARD_NXPNCI_IRQ_GPIO, 1U << BOARD_NXPNCI_IRQ_PIN);
      /* Semaphore */
      irqmask = DisableGlobalIRQ();
      ++IrqSem.semCount;
      EnableGlobalIRQ(irqmask);
      }
}

static status_t I2C_WRITE(uint8_t *pBuff, uint16_t buffLen)
{
    masterXfer.direction = kI2C_Write;
    masterXfer.data = pBuff;
    masterXfer.dataSize = buffLen;

    return I2C_MasterTransferBlocking(NXPNCI_I2C_INSTANCE, &masterXfer);
}

static status_t I2C_READ(uint8_t *pBuff, uint16_t buffLen)
{
    masterXfer.direction = kI2C_Read;
    masterXfer.data = pBuff;
    masterXfer.dataSize = buffLen;

    return I2C_MasterTransferBlocking(NXPNCI_I2C_INSTANCE, &masterXfer);
}

static Status tml_Init(void) {
    i2c_master_config_t masterConfig;
    uint32_t sourceClock;

    gpio_pin_config_t irq_config = {kGPIO_DigitalInput, 0,};
    gpio_pin_config_t ven_config = {kGPIO_DigitalOutput, 0,};

    GPIO_PinInit(BOARD_NXPNCI_IRQ_GPIO, BOARD_NXPNCI_IRQ_PIN, &irq_config);
    GPIO_PinInit(BOARD_NXPNCI_VEN_GPIO, BOARD_NXPNCI_VEN_PIN, &ven_config);

    I2C_MasterGetDefaultConfig(&masterConfig);
    masterConfig.baudRate_Bps = NXPNCI_I2C_BAUDRATE;
    sourceClock = CLOCK_GetFreq(I2C0_CLK_SRC);
    masterXfer.slaveAddress = NXPNCI_I2C_ADDR_7BIT;
    masterXfer.subaddress = 0;
    masterXfer.subaddressSize = 0;
    masterXfer.flags = kI2C_TransferDefaultFlag;
    I2C_MasterInit(NXPNCI_I2C_INSTANCE, &masterConfig, sourceClock);

    /* Create semaphore. */
    IrqSem.semCount  = 0;
    IrqSem.isWaiting = false;
    IrqSem.time_start = 0u;
    IrqSem.timeout = 0u;

    return SUCCESS;
}

static Status tml_DeInit(void) {
    GPIO_PortClear(BOARD_NXPNCI_VEN_GPIO, 1U << BOARD_NXPNCI_VEN_PIN);
    return SUCCESS;
}

static Status tml_Reset(void) {
    GPIO_PortClear(BOARD_NXPNCI_VEN_GPIO, 1U << BOARD_NXPNCI_VEN_PIN);
    Sleep(10);
    GPIO_PortSet(BOARD_NXPNCI_VEN_GPIO, 1U << BOARD_NXPNCI_VEN_PIN);
    Sleep(10);
    return SUCCESS;
}

static Status tml_Tx(uint8_t *pBuff, uint16_t buffLen) {
    if (I2C_WRITE(pBuff, buffLen) != kStatus_Success)
    {
        Sleep(10);
        if(I2C_WRITE(pBuff, buffLen) != kStatus_Success)
        {
            return ERROR;
        }
    }

	return SUCCESS;
}

static Status tml_Rx(uint8_t *pBuff, uint16_t buffLen, uint16_t *pBytesRead) {
    if(I2C_READ(pBuff, 3) == kStatus_Success)
    {
    	if ((pBuff[2] + 3) <= buffLen)
    	{
			if (pBuff[2] > 0)
			{
				if(I2C_READ(&pBuff[3], pBuff[2]) == kStatus_Success)
				{
					*pBytesRead = pBuff[2] + 3;
				}
				else return ERROR;
			} else
			{
				*pBytesRead = 3;
			}
    	}
		else return ERROR;
   }
    else return ERROR;

	return SUCCESS;
}

static Status tml_WaitForRx(uint32_t timeout) {
	uint32_t status = 0;
        uint32_t time;
        uint32_t currentTime;
        uint32_t irqmask;

    if (!timeout) timeout = 0xFFFFFFFFU;
    do {
        /* Check the sem count first. Deal with timeout only if not already set */
        if (IrqSem.semCount)
        {
            irqmask = DisableGlobalIRQ();
            IrqSem.semCount --;
            IrqSem.isWaiting = false;
            EnableGlobalIRQ(irqmask);
            status = kStatus_Success;
        }
        else
        {
            if (IrqSem.isWaiting)
            {
                /* Check for timeout */
                currentTime = Timer_GetTime();

                if (currentTime >= IrqSem.time_start)
                {
                    time = currentTime - IrqSem.time_start;
                }
                else
                {
                    /* lptmr count is 16 bits. */
                    time = 0xFFFFU - IrqSem.time_start + currentTime + 1;
                }
                if (IrqSem.timeout < time)
                {
                    irqmask = DisableGlobalIRQ();
                    IrqSem.isWaiting = false;
                    EnableGlobalIRQ(irqmask);
                    status =  0x2;
                }
            }
            else if (timeout != 0xFFFFFFFFU)    /* If don't wait forever, start the timer */
            {
                /* Start the timeout counter */
                irqmask = DisableGlobalIRQ();
                IrqSem.isWaiting = true;
                EnableGlobalIRQ(irqmask);
                IrqSem.time_start = Timer_GetTime();
                IrqSem.timeout = timeout;
                status = 0x3;
            }
            else
            {
                status = 0x3;
            }
            
        }
    }while((status == 0x3) && (timeout != 0));

	if (status == kStatus_Success) return SUCCESS;

	return ERROR;
}

void tml_Connect(void) {
	tml_Init();
	tml_Reset();
}

void tml_Disconnect(void) {
	tml_DeInit();
}

void tml_Send(uint8_t *pBuffer, uint16_t BufferLen, uint16_t *pBytesSent) {
	if(tml_Tx(pBuffer, BufferLen) == ERROR) *pBytesSent = 0;
	else *pBytesSent = BufferLen;
}

void tml_Receive(uint8_t *pBuffer, uint16_t BufferLen, uint16_t *pBytes, uint16_t timeout) {
	if (tml_WaitForRx(timeout) == ERROR) *pBytes = 0;
	else tml_Rx(pBuffer, BufferLen, pBytes);
}


