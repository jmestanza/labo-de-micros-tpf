#include <stdint.h>
#include "fsl_timer.h"

void Sleep(unsigned int ms)
{
	Timer_Delay_ms(ms);
}
