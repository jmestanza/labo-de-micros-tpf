/*
 * The Clear BSD License
 * Copyright (c) 2016, NXP Semiconductors, Inc.
 * All rights reserved.
 *
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted (subject to the limitations in the disclaimer below) provided
 * that the following conditions are met:
 *
 * o Redistributions of source code must retain the above copyright notice, this list
 *   of conditions and the following disclaimer.
 *
 * o Redistributions in binary form must reproduce the above copyright notice, this
 *   list of conditions and the following disclaimer in the documentation and/or
 *   other materials provided with the distribution.
 *
 * o Neither the name of the copyright holder nor the names of its
 *   contributors may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * NO EXPRESS OR IMPLIED LICENSES TO ANY PARTY'S PATENT RIGHTS ARE GRANTED BY THIS LICENSE.
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#ifndef _BOARD_H_
#define _BOARD_H_

#include "clock_config.h"
#include "fsl_gpio.h"

/*******************************************************************************
 * Definitions
 ******************************************************************************/

/* The board name */
#define BOARD_NAME "HEXIWEAR"

/* The UART to use for debug messages. */
#define BOARD_DEBUG_UART_TYPE DEBUG_CONSOLE_DEVICE_TYPE_UART
#define BOARD_DEBUG_UART_BASEADDR (uint32_t) UART0
#define BOARD_DEBUG_UART_INSTANCE 0U
#define BOARD_DEBUG_UART_CLKSRC SYS_CLK
#define BOARD_DEBUG_UART_CLK_FREQ CLOCK_GetCoreSysClkFreq()
#define BOARD_UART_IRQ UART0_RX_TX_IRQn
#define BOARD_UART_IRQ_HANDLER UART0_RX_TX_IRQHandler

#ifndef BOARD_DEBUG_UART_BAUDRATE
#define BOARD_DEBUG_UART_BAUDRATE 115200
#endif /* BOARD_DEBUG_UART_BAUDRATE */

/* Define the port for oled transfer */
#ifndef BOARD_OLED_CS_GPIO
#define BOARD_OLED_CS_GPIO GPIOB
#endif
#ifndef BOARD_OLED_RST_GPIO
#define BOARD_OLED_RST_GPIO GPIOE
#endif
#ifndef BOARD_OLED_DC_GPIO
#define BOARD_OLED_DC_GPIO GPIOD
#endif
#ifndef BOARD_OLED_PWR_GPIO
#define BOARD_OLED_PWR_GPIO GPIOC
#endif

#ifndef BOARD_OLED_CS_PIN
#define BOARD_OLED_CS_PIN 20U
#endif
#ifndef BOARD_OLED_RST_PIN
#define BOARD_OLED_RST_PIN 6U
#endif
#ifndef BOARD_OLED_DC_PIN
#define BOARD_OLED_DC_PIN 15U
#endif
#ifndef BOARD_OLED_PWR_PIN
#define BOARD_OLED_PWR_PIN 13U
#endif

/* Priority for oled spi */
#define BOARD_OLED_SPI_IRQ_PRIO (4)
#define BOARD_OLED_DMA_TX_IRQ_PRIO (5)
#define BOARD_OLED_DMA_RX_IRQ_PRIO (5)

/* Interrupt for oled spi */
#define BOARD_OLED_SPI_IRQn (SPI2_IRQn)
#define BOARD_OLED_DMA_RX_IRQn (DMA0_IRQn)
#define BOARD_OLED_DMA_TX_IRQn (DMA1_IRQn)
#define BOARD_OLED_DMA_RX_CHN 0
#define BOARD_OLED_DMA_TX_CHN 1
#define BOARD_DSPI_MASTER_DMA_MUX DMAMUX
#define BOARD_DSPI_MASTER_DMA DMA0

/* Define DSPI for oled */
#define BOARD_OLED_DSPI_MASTER_BASEADDR DSPI2
#define BOARD_OLED_DSPI_MASTER_TRANSFER_BAUDRATE 8000000
#define BOARD_OLED_DSPI_MASTER_CLK_FREQ CLOCK_GetFreq(DSPI0_CLK_SRC)

/* The UART for KW40 transfer */
#define BOARD_KW40_UART_CLK_FREQ CLOCK_GetFreq(UART4_CLK_SRC)
#define BOARD_KW40_UART_BASEADDR UART4
#define BOARD_KW40_UART_TRANSFER_BAUDRATE 230400

/* The lptmr for delay */
#define BOARD_DELAY_LPTMR_BASEADDR LPTMR0
#define BOARD_DELAY_LPTMR_IRQn LPTMR0_IRQn
#define BOARD_DELAY_LPTMR_IRQHandler LPTMR0_IRQHandler
#define BOARD_DELAY_LPTMR_CLK_FREQ CLOCK_GetFreq(kCLOCK_LpoClk)

/* The ftm for trigger buzzer */
#define BOARD_BUZZER_FTM_BASEADDR FTM0
#define BOARD_BUZZER_FTM_CHANNEL kFTM_Chnl_1
#define BOARD_BUZZER_FTM_SOURCE_CLOCK CLOCK_GetFreq(kCLOCK_BusClk)

/* The i2c for irthermo read temperature */
#define BOARD_IRTHERMO_I2C_MASTER_BASEADDR I2C0
#define BOARD_IRTHERMO_I2C_MASTER_CLK_FREQ CLOCK_GetFreq(I2C0_CLK_SRC)
#define BOARD_IRTHERMO_I2C_MASTER_SLAVE_ADDR_7BIT 0x5A

/* The gpio for SPI flash */
#define BOARD_SPI_FLASH_DSPI_MASTER_BASEADDR DSPI1
#define BOARD_SPI_FLASH_CS_GPIO GPIOD
#define BOARD_SPI_FLASH_CS_GPIO_PIN 4U

/* Port for motion */
#define BOARD_MOTION_GPIO GPIOB
#define BOARD_MOTION_PORT PORTB
#define BOARD_MOTION_GPIO_PIN 8U
#define BOARD_MOTION_PORT_IRQn PORTB_IRQn
#define BOARD_MOTION_IRQ_HANDLER PORTB_IRQHandler
#define BOARD_MOTION_ENABLE_GPIO GPIOB
#define BOARD_MOTION_ENABLE_GPIO_PIN 19U

/* Port for relay */
#define BOARD_RELAY1_GPIO GPIOC
#define BOARD_RELAY1_PIN 4U
#define BOARD_RELAY2_GPIO GPIOA
#define BOARD_RELAY2_PIN 10U

/* Board led color mapping */
#define LOGIC_LED_ON 0U
#define LOGIC_LED_OFF 1U
#define BOARD_LED_RED_GPIO GPIOC
#define BOARD_LED_RED_GPIO_PORT PORTC
#define BOARD_LED_RED_GPIO_PIN 8U
#define BOARD_LED_BLUE_GPIO GPIOC
#define BOARD_LED_BLUE_GPIO_PORT PORTC
#define BOARD_LED_BLUE_GPIO_PIN 9U
#define BOARD_LED_GREEN_GPIO GPIOD
#define BOARD_LED_GREEN_GPIO_PORT PORTD
#define BOARD_LED_GREEN_GPIO_PIN 0U

/* NXPNCI NFC related declaration */
#define NXPNCI_I2C_INSTANCE I2C0
#define NXPNCI_I2C_BAUDRATE (100000)
#define NXPNCI_I2C_ADDR_7BIT (0x28)
#define BOARD_NXPNCI_IRQ_PORTIRQn PORTB_IRQn
#define BOARD_NXPNCI_IRQ_GPIO (GPIOB)
#define BOARD_NXPNCI_IRQ_PORT (PORTB)
#define BOARD_NXPNCI_IRQ_PIN (13U)
#define BOARD_NXPNCI_VEN_GPIO (GPIOB)
#define BOARD_NXPNCI_VEN_PORT (PORTB)
#define BOARD_NXPNCI_VEN_PIN (11U)

/* Heart Rate related declaration */
#define BOARD_HR_PWR_GPIO GPIOA
#define BOARD_HR_PWR_PIN 13

/* BAT related declaration */
#define BOARD_BAT_SENS_PWR_GPIO GPIOC
#define BOARD_BAT_SENS_PWR_PIN 14

/* TSL related declaration */
#define BOARD_SENSORS_NF_PWR_GPIO GPIOB
#define BOARD_SENSORS_NF_PWR_PIN 12

/* The Flextimer instance/channel */
#define BOARD_ACCEL_FTM_BASEADDR FTM0
#define BOARD_FIRST_TIMER_CHANNEL 0U
#define BOARD_SECOND_TIMER_CHANNEL 1U
#define BOARD_FIRST_CHANNEL_INT kFTM_Chnl0InterruptEnable
#define BOARD_SECOND_CHANNEL_INT kFTM_Chnl1InterruptEnable
#define BOARD_FTM_IRQ_HANDLER_FUNC FTM0_IRQHandler
#define BOARD_FTM_IRQ_ID FTM0_IRQn
/* Get source clock for TPM driver */
#define BOARD_TIMER_SOURCE_CLOCK CLOCK_GetFreq(kCLOCK_BusClk)
/* I2C source clock */
#define BOARD_ACCEL_I2C_CLK_SRC I2C1_CLK_SRC
#define BOARD_ACCEL_I2C_BASEADDR I2C1
#define BOARD_ACCEL_I2C_CLK_FREQ CLOCK_GetFreq(BOARD_ACCEL_I2C_CLK_SRC)
#define ACCEL_I2C_CLK_FREQ BOARD_ACCEL_I2C_CLK_FREQ

#define BOARD_GYRO_I2C_CLK_SRC I2C1_CLK_SRC
#define BOARD_GYRO_I2C_BASEADDR I2C1
#define BOARD_GYRO_I2C_CLK_FREQ CLOCK_GetFreq(BOARD_GYRO_I2C_CLK_SRC)

#define I2C_BAUDRATE 100000U
#define I2C_RELEASE_SDA_PORT PORTC
#define I2C_RELEASE_SCL_PORT PORTC
#define I2C_RELEASE_SDA_GPIO GPIOC
#define I2C_RELEASE_SDA_PIN 11U
#define I2C_RELEASE_SCL_GPIO GPIOC
#define I2C_RELEASE_SCL_PIN 10U
#define I2C_RELEASE_BUS_COUNT 100U

/* HEARTRATE  */
#define BOARD_HEARTRATE_I2C_CLK_SRC I2C0_CLK_SRC
#define BOARD_HEARTRATE_I2C_BASEADDR I2C0
#define BOARD_HEARTRATE_I2C_CLK_FREQ CLOCK_GetFreq(BOARD_HEARTRATE_I2C_CLK_SRC)
#define HEARTRATE_I2C_RELEASE_SDA_PORT PORTB
#define HEARTRATE_I2C_RELEASE_SCL_PORT PORTB
#define HEARTRATE_I2C_RELEASE_SDA_GPIO GPIOB
#define HEARTRATE_I2C_RELEASE_SDA_PIN 1U
#define HEARTRATE_I2C_RELEASE_SCL_GPIO GPIOB
#define HEARTRATE_I2C_RELEASE_SCL_PIN 0U
#define HEARTRATE_I2C_BAUDRATE 400000U
#define HEARTRATE_I2C_RELEASE_BUS_COUNT 100U

/* Pressure sensor(MPL3115A2) related declaration. */
#define BOARD_PRESSURE_I2C_BASEADDR I2C1
#define BOARD_PRESSURE_I2C_BAUDRATE 400000U
#define BOARD_PRESSURE_I2C_CLK_SRC I2C1_CLK_SRC
#define BOARD_PRESSURE_I2C_CLK_FREQ CLOCK_GetFreq(BOARD_PRESSURE_I2C_CLK_SRC)
#define PRESSURE_I2C_RELEASE_SDA_PORT PORTC
#define PRESSURE_I2C_RELEASE_SCL_PORT PORTC
#define PRESSURE_I2C_RELEASE_SDA_GPIO GPIOC
#define PRESSURE_I2C_RELEASE_SDA_PIN 11U
#define PRESSURE_I2C_RELEASE_SCL_GPIO GPIOC
#define PRESSURE_I2C_RELEASE_SCL_PIN 10U
#define PRESSURE_I2C_RELEASE_BUS_COUNT 100U

/* Humidity sensor(HTU21D) related declaration. */
#define BOARD_HUMIDITY_I2C_BASEADDR I2C0
#define BOARD_HUMIDITY_I2C_BAUDRATE 400000U
#define BOARD_HUMIDITY_I2C_CLK_SRC I2C0_CLK_SRC
#define BOARD_HUMIDITY_I2C_CLK_FREQ CLOCK_GetFreq(BOARD_HUMIDITY_I2C_CLK_SRC)
#define HUMIDITY_I2C_RELEASE_SDA_PORT PORTB
#define HUMIDITY_I2C_RELEASE_SCL_PORT PORTB
#define HUMIDITY_I2C_RELEASE_SDA_GPIO GPIOB
#define HUMIDITY_I2C_RELEASE_SDA_PIN 1U
#define HUMIDITY_I2C_RELEASE_SCL_GPIO GPIOC
#define HUMIDITY_I2C_RELEASE_SCL_PIN 0U
#define HUMIDITY_I2C_RELEASE_BUS_COUNT 100U
#define HUMIDITY_POWER_GPIO GPIOB
#define HUMIDITY_POWER_GPIO_PIN 12U

/* Humidity sensor(HTU21D) related declaration. */
#define BOARD_AMBIENT_LIGHT_I2C_BASEADDR I2C0
#define BOARD_AMBIENT_LIGHT_I2C_BAUDRATE 400000U
#define BOARD_AMBIENT_LIGHT_I2C_CLK_SRC I2C0_CLK_SRC
#define BOARD_AMBIENT_LIGHT_I2C_CLK_FREQ CLOCK_GetFreq(BOARD_AMBIENT_LIGHT_I2C_CLK_SRC)
#define AMBIENT_LIGHT_I2C_RELEASE_SDA_PORT PORTB
#define AMBIENT_LIGHT_I2C_RELEASE_SCL_PORT PORTB
#define AMBIENT_LIGHT_I2C_RELEASE_SDA_GPIO GPIOB
#define AMBIENT_LIGHT_I2C_RELEASE_SDA_PIN 1U
#define AMBIENT_LIGHT_I2C_RELEASE_SCL_GPIO GPIOC
#define AMBIENT_LIGHT_I2C_RELEASE_SCL_PIN 0U
#define AMBIENT_LIGHT_I2C_RELEASE_BUS_COUNT 100U
#define AMBIENT_LIGHT_POWER_GPIO GPIOB
#define AMBIENT_LIGHT_POWER_GPIO_PIN 12U

/* SDHC base address, clock and card detection pin */
#define BOARD_SDHC_BASEADDR SDHC
#define BOARD_SDHC_CLKSRC kCLOCK_CoreSysClk
#define BOARD_SDHC_CLK_FREQ CLOCK_GetFreq(kCLOCK_CoreSysClk)
#define BOARD_SDHC_IRQ SDHC_IRQn

/* If the SD card detected by DATA3, this has no use in code. */
#define BOARD_SDHC_CD_GPIO_BASE GPIOE
#ifndef BOARD_SDHC_CD_GPIO_PIN
#define BOARD_SDHC_CD_GPIO_PIN 0U
#endif
#define BOARD_SDHC_CD_PORT_BASE PORTE
#define BOARD_SDHC_CD_PORT_IRQ PORTE_IRQn
#define BOARD_SDHC_CD_PORT_IRQ_HANDLER PORTE_IRQHandler
#define BOARD_SDHC_CARD_INSERT_CD_LEVEL (1U)

#define LED_RED_INIT(output)                                           \
    GPIO_PinWrite(BOARD_LED_RED_GPIO, BOARD_LED_RED_GPIO_PIN, output); \
    BOARD_LED_RED_GPIO->PDDR |= (1U << BOARD_LED_RED_GPIO_PIN)                        /*!< Enable target LED_RED */
#define LED_RED_ON() GPIO_PortClear(BOARD_LED_RED_GPIO, 1U << BOARD_LED_RED_GPIO_PIN) /*!< Turn on target LED_RED */
#define LED_RED_OFF() GPIO_PortSet(BOARD_LED_RED_GPIO, 1U << BOARD_LED_RED_GPIO_PIN)  /*!< Turn off target LED_RED */
#define LED_RED_TOGGLE() \
    GPIO_PortToggle(BOARD_LED_RED_GPIO, 1U << BOARD_LED_RED_GPIO_PIN) /*!< Toggle on target LED_RED */

#define LED_GREEN_INIT(output)                                             \
    GPIO_PinWrite(BOARD_LED_GREEN_GPIO, BOARD_LED_GREEN_GPIO_PIN, output); \
    BOARD_LED_GREEN_GPIO->PDDR |= (1U << BOARD_LED_GREEN_GPIO_PIN) /*!< Enable target LED_GREEN */
#define LED_GREEN_ON() \
    GPIO_PortClear(BOARD_LED_GREEN_GPIO, 1U << BOARD_LED_GREEN_GPIO_PIN) /*!< Turn on target LED_GREEN */
#define LED_GREEN_OFF() \
    GPIO_PortSet(BOARD_LED_GREEN_GPIO, 1U << BOARD_LED_GREEN_GPIO_PIN) /*!< Turn off target LED_GREEN */
#define LED_GREEN_TOGGLE() \
    GPIO_PortToggle(BOARD_LED_GREEN_GPIO, 1U << BOARD_LED_GREEN_GPIO_PIN) /*!< Toggle on target LED_GREEN */

#define LED_BLUE_INIT(output)                                            \
    GPIO_PinWrite(BOARD_LED_BLUE_GPIO, BOARD_LED_BLUE_GPIO_PIN, output); \
    BOARD_LED_BLUE_GPIO->PDDR |= (1U << BOARD_LED_BLUE_GPIO_PIN)                         /*!< Enable target LED_BLUE */
#define LED_BLUE_ON() GPIO_PortClear(BOARD_LED_BLUE_GPIO, 1U << BOARD_LED_BLUE_GPIO_PIN) /*!< Turn on target LED_BLUE*/
#define LED_BLUE_OFF() GPIO_PortSet(BOARD_LED_BLUE_GPIO, 1U << BOARD_LED_BLUE_GPIO_PIN)  /*!< Turn off target LED_BLUE*/
#define LED_BLUE_TOGGLE() \
    GPIO_PortToggle(BOARD_LED_BLUE_GPIO, 1U << BOARD_LED_BLUE_GPIO_PIN) /*!< Toggle on target LED_BLUE */

#if defined(__cplusplus)
extern "C" {
#endif /* __cplusplus */

/*******************************************************************************
 * API
 ******************************************************************************/
void BOARD_InitDebugConsole(void);
#if defined(SDK_I2C_BASED_COMPONENT_USED) && SDK_I2C_BASED_COMPONENT_USED
void BOARD_I2C_Init(I2C_Type *base, uint32_t clkSrc_Hz);
status_t BOARD_I2C_Send(I2C_Type *base,
                        uint8_t deviceAddress,
                        uint32_t subAddress,
                        uint8_t subaddressSize,
                        uint8_t *txBuff,
                        uint8_t txBuffSize);
status_t BOARD_I2C_Receive(I2C_Type *base,
                           uint8_t deviceAddress,
                           uint32_t subAddress,
                           uint8_t subaddressSize,
                           uint8_t *rxBuff,
                           uint8_t rxBuffSize);
void BOARD_Accel_I2C_Init(void);
status_t BOARD_Accel_I2C_Send(uint8_t deviceAddress, uint32_t subAddress, uint8_t subaddressSize, uint32_t txBuff);
status_t BOARD_Accel_I2C_Receive(uint8_t deviceAddress, uint32_t subAddress, uint8_t subaddressSize, uint8_t *rxBuff, uint8_t rxBuffSize);
void BOARD_Pressure_I2C_Init(void);
status_t BOARD_Pressure_I2C_Send(uint8_t deviceAddress, uint32_t subAddress, uint8_t subaddressSize, uint32_t txBuff);
status_t BOARD_Pressure_I2C_Receive(uint8_t deviceAddress, uint32_t subAddress, uint8_t subaddressSize, uint8_t *rxBuff, uint8_t rxBuffSize);
void BOARD_Gyroscope_I2C_Init(void);
status_t BOARD_Gyroscope_I2C_Send(uint8_t deviceAddress, uint32_t subAddress, uint8_t subaddressSize, uint32_t txBuff);
status_t BOARD_Gyroscope_I2C_Receive(uint8_t deviceAddress, uint32_t subAddress, uint8_t subaddressSize, uint8_t *rxBuff, uint8_t rxBuffSize);
void BOARD_HeartRate_I2C_Init(void);
status_t BOARD_HeartRate_I2C_Send(uint8_t deviceAddress, uint32_t subAddress, uint8_t subaddressSize, uint32_t txBuff);
status_t BOARD_HeartRate_I2C_Receive(uint8_t deviceAddress, uint32_t subAddress, uint8_t subaddressSize, uint8_t *rxBuff, uint8_t rxBuffSize);
void BOARD_Humidity_I2C_Init(void);
status_t BOARD_Humidity_I2C_Send(uint8_t deviceAddress, uint32_t subAddress, uint8_t subaddressSize, uint32_t txBuff);
status_t BOARD_Humidity_I2C_Receive(uint8_t deviceAddress, uint32_t subAddress, uint8_t subaddressSize, uint8_t *rxBuff, uint8_t rxBuffSize);
void BOARD_Ambientlight_I2C_Init(void);
status_t BOARD_Ambientlight_I2C_Send(uint8_t deviceAddress, uint32_t subAddress, uint8_t subaddressSize, uint32_t txBuff);
status_t BOARD_Ambientlight_I2C_Receive(uint8_t deviceAddress, uint32_t subAddress, uint8_t subaddressSize, uint8_t *rxBuff, uint8_t rxBuffSize);
#endif /* SDK_I2C_BASED_COMPONENT_USED */

#if defined(__cplusplus)
}
#endif /* __cplusplus */

#endif /* _BOARD_H_ */
