/*
 * The Clear BSD License
 * Copyright (c) 2016, NXP Semiconductors, Inc.
* All rights reserved.
*
 * 
* Redistribution and use in source and binary forms, with or without modification,
* are permitted (subject to the limitations in the disclaimer below) provided
*  that the following conditions are met:
*
* o Redistributions of source code must retain the above copyright notice, this list
*   of conditions and the following disclaimer.
*
* o Redistributions in binary form must reproduce the above copyright notice, this
*   list of conditions and the following disclaimer in the documentation and/or
*   other materials provided with the distribution.
*
* o Neither the name of the copyright holder nor the names of its
*   contributors may be used to endorse or promote products derived from this
*   software without specific prior written permission.
*
* NO EXPRESS OR IMPLIED LICENSES TO ANY PARTY'S PATENT RIGHTS ARE GRANTED BY THIS LICENSE.
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
* ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
* ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
* ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
* SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#include "uart_kw40_transfer.h"
/*******************************************************************************
 * Definitions
 ******************************************************************************/

/*******************************************************************************
 * Variables
 ******************************************************************************/
uart_handle_t g_uartHandle;
static hostInterface_packet_t hostInterface_rxPacket = {0};
static hostInterface_rxState_t hostInterface_rxState = hostInterface_rxState_idle;
volatile touch_type_t pressedTouch = touch_invalid;
volatile bool g_bleAdvEnable = false;
volatile bool g_bondKeySet = false;
volatile bool g_Notification = false;
volatile uint8_t g_RxNotificationData[3] = {0};
static hostInterface_packet_t hostInterface_okPacket = {
    .start1 = 0x55, .start2 = 0xAA, .type = packetType_OK, .length = 0, .data[0] = gHostInterface_trailerByte};
/*******************************************************************************
 * Code
 ******************************************************************************/
/* UART user callback */
void UART_UserCallback(UART_Type *base, uart_handle_t *handle, status_t status, void *userData)
{
    /* If the receive is successful */
    if (kStatus_UART_RxIdle == status)
    {
        switch (hostInterface_rxState)
        {
            case hostInterface_rxState_idle:
            {
                /* If the receive data is gHostInterface_startByte1, then recevie the other 3 header bytes */
                if (gHostInterface_startByte1 == hostInterface_rxPacket.start1)
                {
                    hostInterface_rxState = hostInterface_rxState_headerReceived;
                    handle->rxDataSize = gHostInterface_headerSize - 1;
                }
                else
                {
                    /* Reset the RX buffer pointer and receive data size in UART transfer handle*/
                    handle->rxData = (uint8_t *)&hostInterface_rxPacket;
                    handle->rxDataSize = 1;
                }
                break;
            }
            case hostInterface_rxState_headerReceived:
                if ((gHostInterface_startByte1 != hostInterface_rxPacket.start1) ||
                    (gHostInterface_startByte2 != (hostInterface_rxPacket.start2 & 0xFE)) ||
                    (hostInterface_rxPacket.length > gHostInterface_dataSize))
                {
                    /* Reset the RX buffer pointer and receive data size in UART transfer handle*/
                    hostInterface_rxState = hostInterface_rxState_idle;
                    handle->rxData = (uint8_t *)&hostInterface_rxPacket;
                    handle->rxDataSize = 1;
                }
                else
                {
                    if (0 == hostInterface_rxPacket.length)
                    {
                        /* Advance to "wait-trailer-bit" state to receive the trailer data */
                        hostInterface_rxState = hostInterface_rxState_trailerWait;
                        handle->rxDataSize = 1;
                    }
                    else
                    {
                        /* Advance to "data-wait" state to receive data */
                        hostInterface_rxState = hostInterface_rxState_dataWait;
                        handle->rxDataSize = hostInterface_rxPacket.length;
                    }
                }
                break;

            case hostInterface_rxState_dataWait:
            {
                /* Advance to "wait-trailer-bit" state to receive the trailer data */
                hostInterface_rxState = hostInterface_rxState_trailerWait;
                handle->rxDataSize = 1;
                handle->rxDataSizeAll = 1;
                break;
            }

            case hostInterface_rxState_trailerWait:
            {
                if (gHostInterface_trailerByte == hostInterface_rxPacket.data[hostInterface_rxPacket.length])
                {
                    switch (hostInterface_rxPacket.type)
                    {
                        case packetType_pressRight:
                        {
                            pressedTouch = touch_right;
                            break;
                        }
                        case packetType_pressLeft:
                        {
                            pressedTouch = touch_left;
                            break;
                        }
                        case packetType_advModeSend:
                        {
                            g_bleAdvEnable = hostInterface_rxPacket.data[0];
                            break;
                        }
                        case packetType_passDisplay:
                        {
                            /* Send confirm package OK message to kw40 */
                            uart_transfer_t xfer;
                            xfer.data = (uint8_t *)&hostInterface_okPacket;
                            xfer.dataSize = sizeof(hostInterface_okPacket);
                            UART_TransferSendNonBlocking(BOARD_KW40_UART_BASEADDR, &g_uartHandle, &xfer);

                            g_bondKeySet = true;
                            memcpy((uint8_t *)&g_RxNotificationData[0], hostInterface_rxPacket.data, 3);
                            break;
                        }
                        case packetType_alertIn:
                        {
                            /* Send confirm package OK message to kw40 */
                            uart_transfer_t xfer;
                            xfer.data = (uint8_t *)&hostInterface_okPacket;
                            xfer.dataSize = sizeof(hostInterface_okPacket);
                            UART_TransferSendNonBlocking(BOARD_KW40_UART_BASEADDR, &g_uartHandle, &xfer);

                            g_Notification = true;
                            memset((uint8_t *)&g_RxNotificationData[0], 0, sizeof(g_RxNotificationData));
                            memcpy((uint8_t *)&g_RxNotificationData[0], hostInterface_rxPacket.data, 3);
                            break;
                        }
                        default:
                        {
                            pressedTouch = touch_invalid;
                            break;
                        }
                    }
                }
                /* Reset UART RX data size and RX data buffer pointer in UART transfer handle for the next transmit */
                hostInterface_rxState = hostInterface_rxState_idle;
                handle->rxDataSize = 1;
                handle->rxData = (uint8_t *)&hostInterface_rxPacket;
                break;
            }
            default:
            {
                /* Reset the RX buffer pointer and receive data size in UART transfer handle*/
                hostInterface_rxState = hostInterface_rxState_idle;
                handle->rxDataSize = 1;
                handle->rxData = (uint8_t *)&hostInterface_rxPacket;
                break;
            }
        }
    }
}

void KW40_UART_Init(void)
{
    uart_config_t config;
    uart_transfer_t receiveXfer;
    /*
     * config.baudRate_Bps = 115200U;
     * config.parityMode = kUART_ParityDisabled;
     * config.stopBitCount = kUART_OneStopBit;
     * config.txFifoWatermark = 0;
     * config.rxFifoWatermark = 1;
     * config.enableTx = false;
     * config.enableRx = false;
     */
    UART_GetDefaultConfig(&config);
    config.baudRate_Bps = BOARD_KW40_UART_TRANSFER_BAUDRATE;
    config.stopBitCount = kUART_TwoStopBit;
    config.enableTx = true;
    config.enableRx = true;

    UART_Init(BOARD_KW40_UART_BASEADDR, &config, BOARD_KW40_UART_CLK_FREQ);
    UART_TransferCreateHandle(BOARD_KW40_UART_BASEADDR, &g_uartHandle, UART_UserCallback, NULL);

    receiveXfer.data = (uint8_t *)&hostInterface_rxPacket;
    receiveXfer.dataSize = 1;
    UART_TransferReceiveNonBlocking(BOARD_KW40_UART_BASEADDR, &g_uartHandle, &receiveXfer, NULL);
}
