/*
 * The Clear BSD License
 * Copyright (c) 2016, NXP Semiconductors, Inc.
* All rights reserved.
*
 * 
* Redistribution and use in source and binary forms, with or without modification,
* are permitted (subject to the limitations in the disclaimer below) provided
*  that the following conditions are met:
*
* o Redistributions of source code must retain the above copyright notice, this list
*   of conditions and the following disclaimer.
*
* o Redistributions in binary form must reproduce the above copyright notice, this
*   list of conditions and the following disclaimer in the documentation and/or
*   other materials provided with the distribution.
*
* o Neither the name of the copyright holder nor the names of its
*   contributors may be used to endorse or promote products derived from this
*   software without specific prior written permission.
*
* NO EXPRESS OR IMPLIED LICENSES TO ANY PARTY'S PATENT RIGHTS ARE GRANTED BY THIS LICENSE.
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
* ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
* ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
* ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
* SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#ifndef _UART_KW40_TRANSFER_H_
#define _UART_KW40_TRANSFER_H_

#include "board.h"
#include "fsl_uart.h"

/**********************************************************************************************************************
 * Definitions
 *********************************************************************************************************************/
#define gHostInterface_startByte1 0x55
#define gHostInterface_startByte2 0xAA
#define gHostInterface_trailerByte 0x45
#define gHostInterface_dataSize 23
#define gHostInterface_headerSize 4

/*!
 * @brief Touch type.
 *
 */
typedef enum { touch_left = 0, touch_right = 1, touch_invalid = 0xFF } touch_type_t;

/*!
 * @brief Packet definitions
 *
 * Types of packets exchanged.
 */
typedef enum {
    packetType_pressUp = 0,                   /*!< Press up event. */
    packetType_pressDown = 1,                 /*!< Press down event. */
    packetType_pressLeft = 2,                 /*!< Press left event. */
    packetType_pressRight = 3,                /*!< Press right event. */
    packetType_slide = 4,                     /*!< Slide event. */
    packetType_batteryLevel = 5,              /*!< Battery service. */
    packetType_accel = 6,                     /*!< Motion service. */
    packetType_ambiLight = 7,                 /*!< weather service. */
    packetType_pressure = 8,                  /*!< Pressure service. */
    packetType_gyro = 9,                      /*!< Motion service. */
    packetType_temperature = 10,              /*!< Tempreature service. */
    packetType_humidity = 11,                 /*!< Weather service. */
    packetType_magnet = 12,                   /*!< Motion service. */
    packetType_heartRate = 13,                /*!< Send buffer. */
    packetType_steps = 14,                    /*!< Health service. */
    packetType_calories = 15,                 /*!< Health servicer. */
    packetType_alertIn = 16,                  /*!< Alert service. */
    packetType_alertOut = 17,                 /*!< Alert service. */
    packetType_passDisplay = 18,              /*!< Type for password confirmation. */
    packetType_otapKW40Started = 19,          /*!< Types for OTAP. */
    packetType_otapMK64Started = 20,          /*!< Types for OTAP. */
    packetType_otapCompleted = 21,            /*!< Complete for OTAP. */
    packetType_otapFailed = 22,               /*!< Failed for OTAP. */
    packetType_buttonsGroupToggleActive = 23, /*!< Button group service. */
    packetType_buttonsGroupGetActive = 24,    /*!< Button group service. */
    packetType_buttonsGroupSendActive = 25,   /*!< Button group service. */
    packetType_advModeGet = 26,               /*!< Adv mode service. */
    packetType_advModeSend = 27,              /*!< Adv mode service. */
    packetType_advModeToggle = 28,            /*!< Adv mode service. */
    packetType_appMode = 29,                  /*!< App Mode Service */
    packetType_linkStateGet = 30,             /*!< Link state service. */
    packetType_linkStateSend = 31,            /*!< Link state service. */
    packetType_notification = 32,             /*!< Notifications */
    packetType_buildVersion = 33,             /*!< Build version */
    packetType_sleepON = 34,                  /*!< SLEEP ON */
    packetType_sleepOFF = 35,                 /*!< SLEEP OFF. */
    packetType_OK = 255                       /*!< OK Packet. */
} hostInterface_packetType_t;

/*!
 * @brief Host transfer packet struct.
 *
 * Packet struct for every transfer.
 */
typedef struct
{
    /* NOTE: Size of struct must be multiplier of 4 ! */
    uint8_t start1;                            /*!< Start byte 1. */
    uint8_t start2;                            /*!< Start byte 2. */
    hostInterface_packetType_t type;           /*!< Packet type. */
    uint8_t length;                            /*!< Data length for this tranmition. */
    uint8_t data[gHostInterface_dataSize + 1]; /*!< recevier buffer. */
} hostInterface_packet_t;

typedef enum {
    alertIn_type_notification = 1,
    alertIn_type_settings = 2,
    alertIn_type_timeUpdate = 3,
} hostInterface_alertIn_type_t;

/*!
 * @brief Host interface state struct.
 *
 */
typedef enum {
    hostInterface_rxState_idle = 0,           /*!< Host receive state for idle. */
    hostInterface_rxState_headerReceived = 3, /*!< Host receive state for header recevie. */
    hostInterface_rxState_dataWait = 4,       /*!< Host receive state for data wait. */
    hostInterface_rxState_trailerWait = 5     /*!< Host receive state for trailer wait. */
} hostInterface_rxState_t;

/**********************************************************************************************************************
 * API
 *********************************************************************************************************************/

#if defined(__cplusplus)
extern "C" {
#endif

/*!
 *@brief Intialize the UART which will transfer with KW40.
 *
 */
void KW40_UART_Init(void);

#if defined(__cplusplus)
}
#endif

#endif /* _UART_KW40_TRANSFER_H_ */
