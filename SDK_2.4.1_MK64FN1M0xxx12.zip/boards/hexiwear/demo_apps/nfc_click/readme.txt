Overview
========
The hexiwear_nfc_click demo application provides a sanity demo for users to use the nfc. 
The purpose of this demo is to show how to use the nfc (P2P mode, Read/Write mode, Card Emulation mode), and to provide a simple project for debugging and further development.

Toolchain supported
===================
- Keil MDK 5.24a
- IAR embedded Workbench 8.22.2
- GCC ARM Embedded 7-2017-q4-major
- MCUXpresso10.2.0

Hardware requirements
=====================
- Mini/micro USB cable
- Hexiwear Main board/Hexiwear Docking Station/NFC click board
- NFC Forum Tag (or NFC TAG click board)
- Personal Computer

Board settings
==============
Please plug the Hexiwear Main board to the Hexiwear Docking Station board and plug the NFC click board to MIKROBUS1 on Hexiwear Docking Station board.

Prepare the Demo
================
1.  Connect a mini USB cable between the PC host and the OpenSDA USB port on the board.
2.  Open a serial terminal on PC for OpenSDA serial device with these settings:
    - 115200 baud rate
    - 8 data bits
    - No parity
    - One stop bit
    - No flow control
3.  Download the program to the target board.
4.  Either press the reset button on your board or launch the debugger in your IDE to begin running the demo.
5.  Install NFC TAGWriter application on the NFC enabled mobile phone

Running the demo
================
When connected to PC, you can see the some other information from the terminal as below.

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
This is HEXIWEAR NFC CLICK example!

WAITING FOR DEVICE DISCOVERY
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

first to test the R/W mode, tapping a card to NFC, NFC will read the card information and print it to  the terminal. The information depends on the card type and the information contained in the cards
 
 o "URL" cards: related URL is been displayed on the screen
 o "Text" cards: related TEXT is been displayed on the screen
 o "Business" cards: relates Full name is displayed on the screen
    .........

If you tapping your bus card to the click board, the log will be such as:

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
- POLL MODE: Remote T4T activated  
SENS_RES = 0x08 0x00   NFCID = 0x22 0x29 0xeb 0xa7 
SEL_RES = 0x20
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ 

you can use NFC TAG2 click to create your own "URL" card using "NFC TagWriter by NXP" application as:
- "URL" cards: 
    NDEF URI record (Link)
    Example: "www.nxp.com"

and then tapping the NFC TAG2 click board to the NFC click board the log will be as:
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
- POLL MODE: Remote T2T activated
SENS_RES = 0x44 0x00   NFCID = 0x04 0x3f 0x5d 0x72 0x08 0x4f 0x80        
SEL_RES = 0x00                                                                          --- NDEF record received:
URI record: http://www.nxp.com
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

you can use NFC TAG2 click to create your own "TEXT" card using "NFC TagWriter by NXP" application as:

- "Text" cards:
    NDEF text record (Plain text)
    Example: "Hello world !"
    
and then tapping the NFC TAG2 click board to the NFC click board the log will be as:   
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
- POLL MODE: Remote T2T activated
SENS_RES = 0x44 0x00    NFCID = 0x04 0x3f 0x5d 0x72 0x08 0x4f 0x80
SEL_RES = 0x00
--- NDEF record received:
Text record: hello world
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

you can use NFC TAG2 click to create your own "Business" card using "NFC TagWriter by NXP" application as:
- "Business" cards: 
    NDEF MIME type record, "text/x-vCard" type (Business card)
    Example: Full name="Gregory Camuzat"

and then tapping the NFC TAG2 click board to the NFC click board the log will be as:   
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
- POLL MODE: Remote T2T activated
SENS_RES = 0x44 0x00  NFCID = 0x04 0x3f 0x5d 0x72 0x08 0x4f 0x80 
SEL_RES = 0x00
--- NDEF record received:
vCard:
BEGIN:VCARD
VERSION:2.1
N:;Gregory Camuzat;;;
FN:Gregory Camuzat
END:VCARD
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

second to test the P2P mode, Bringing a NFC android phone,
access URL" www.nxp.com" and beaming the URL 
"www.nxp.com", the terminal will gives such result:

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
- P2P TARGET MODE: Activated from remote Initiator
--- NDEF record received:
URI record: http://www.nxp.com/
--- NDEF Record sent
PEER LOST
WAITING FOR DEVICE DISCOVERY
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

third to test the NFC Card Emulation. Bring a NFC card Reader close
to the NFC click board and read the NFC information. The log will be 
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

- LISTEN MODE: Activated from remote Reader
READER DISCONNECTED
WAITING FOR DEVICE DISCOVERY

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
If there is no NFC reader, you can install "NFC Reader" application on your
NFC enabled mobile phone and disable the PTP Mode (delete the P2P_SUPPORT from your project).
Then you can use the mobile phone as the NFC Reader with the "NFC Reader" opening.
Then the NFC card information can be read and will show on NFC Reader.
Customization options
=====================

