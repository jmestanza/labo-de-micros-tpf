/*
 * The Clear BSD License
 * Copyright (c) 2017, NXP Semiconductor
 * All rights reserved.
 *
 * 
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted (subject to the limitations in the disclaimer below) provided
 *  that the following conditions are met:
 *
 * o Redistributions of source code must retain the above copyright notice, this list
 *   of conditions and the following disclaimer.
 *
 * o Redistributions in binary form must reproduce the above copyright notice, this
 *   list of conditions and the following disclaimer in the documentation and/or
 *   other materials provided with the distribution.
 *
 * o Neither the name of NXP Semiconductor nor the names of its
 *   contributors may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * NO EXPRESS OR IMPLIED LICENSES TO ANY PARTY'S PATENT RIGHTS ARE GRANTED BY THIS LICENSE.
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

#include <stdlib.h>
#include <string.h>
#include "board.h"
#include "fsl_gpio.h"
#include "fsl_debug_console.h"
#include "ndef_message.h"
#include "screens_resources.h"
#include "fsl_psp27801.h"
#include "nfc.h"
#include "ndef_helper.h"
#include "uart_kw40_transfer.h"
#include "tool.h"

#include "fsl_device_registers.h"
#include "clock_config.h"
#include "fsl_port.h"
#include "pin_mux.h"
/*******************************************************************************
 * Definitions
 ******************************************************************************/
// Version of Board and FW, change if needed
// Notice that only one char per define is allowed

#define CHAR_FW_MAJ '2'
#define CHAR_FW_MIN '0'

// Write back the timing as a NDEF Message(useful when you have no display
// to look at the timing and want to read it out later
//#define WRITE_TIME_VIA_NDEF

// Following I2C NFC devices are supported:
// NTAG I2C (standard)
#define NTAG_I2C_PLUS // 2kB version

// Following Boards are supported:
// FRDM_K82F has to be defined in project properties defined symbols

// Following Polling methods are supported
// Polling (standard)
// Interrupted, switched via following define instead of Polling
#define INTERRUPT

#ifdef I2C_CMSIS
#define NTAG_I2C_MASTER_BASEADDR &Driver_I2C0
#define I2C_MASTER_IRQ I2C0_IRQn
#endif

#ifdef I2C_FSL
#define NTAG_I2C_MASTER_BASEADDR I2C0
#define I2C_MASTER_CLK_SRC I2C0_CLK_SRC
#endif

#define print_buf(x,y,z)  {int loop; printf(x); for(loop=0;loop<z;loop++) printf("0x%.2x ", y[loop]); printf("\r\n");}

typedef enum _led_name
{
    NONE_LED,
    RED_LED,
    BLUE_LED,
    GREEN_LED,
    ALL_LED
} led_name_t;

typedef enum _led_status
{
    kStatus_led_on,
    kStatus_led_off,
} led_status_t;

/*******************************************************************************
 * Prototypes
 ******************************************************************************/
void HAL_Setup(void);
static void InitLeds(led_status_t status);
static void LED_Set_ON_OFF(led_name_t led_name, led_status_t led_status);

#if defined P2P_SUPPORT || defined CARDEMU_SUPPORT
void NdefPush_Cb(unsigned char *pNdefRecord, unsigned short NdefRecordSize) {
    printf("--- NDEF Record sent\r\n");
}
#endif

/*******************************************************************************
 * Variable
 ******************************************************************************/
#if defined P2P_SUPPORT || defined CARDEMU_SUPPORT
const char NDEF_MESSAGE[] = { 0xD1,   /* MB/ME/CF/1/IL/TNF*/
        0x01,   /* TYPE LENGTH */
        0x07,   /* PAYLOAD LENTGH */
        'T',    /* TYPE */
        0x02,   /* Status */
        'e', 'n', /* Language */
        'T', 'e', 's', 't' };
#endif

/* Discovery loop configuration according to the targeted modes of operation */
unsigned char DiscoveryTechnologies[] = {
#if defined P2P_SUPPORT || defined RW_SUPPORT
    MODE_POLL | TECH_PASSIVE_NFCA,
    MODE_POLL | TECH_PASSIVE_NFCF,
#endif
#ifdef RW_SUPPORT
    MODE_POLL | TECH_PASSIVE_NFCB,
    MODE_POLL | TECH_PASSIVE_15693,
#endif
#ifdef P2P_SUPPORT
    MODE_POLL | TECH_ACTIVE_NFCF,
#endif
#if defined P2P_SUPPORT || defined CARDEMU_SUPPORT
    MODE_LISTEN | TECH_PASSIVE_NFCA,
#endif
#if defined CARDEMU_SUPPORT
    MODE_LISTEN | TECH_PASSIVE_NFCB,
#endif
#ifdef P2P_SUPPORT
    MODE_LISTEN | TECH_PASSIVE_NFCF,
    MODE_LISTEN | TECH_ACTIVE_NFCA,
    MODE_LISTEN | TECH_ACTIVE_NFCF,
#endif
};

oled_dynamic_area_t splashArea = {.xCrd = 0, .yCrd = 0};

/*******************************************************************************
 * Code
 ******************************************************************************/
static void BOARD_InitNFCHardware(void)
{
    PORT_SetPinInterruptConfig(BOARD_NXPNCI_IRQ_PORT, BOARD_NXPNCI_IRQ_PIN, kPORT_InterruptRisingEdge);
}

#if defined P2P_SUPPORT || defined RW_SUPPORT
void NdefPull_Cb(unsigned char *pNdefMessage, unsigned short NdefMessageSize)
{
    unsigned char *pNdefRecord = pNdefMessage;
    NdefRecord_t NdefRecord;
    unsigned char save;

    if (pNdefMessage == NULL)
    {
        printf("--- Issue during NDEF message reception (check provisioned buffer size) \r\n");
        return;
    }

    while (pNdefRecord != NULL)
    {
        printf("--- NDEF record received:\r\n");

        NdefRecord = DetectNdefRecordType(pNdefRecord);

        switch(NdefRecord.recordType)
        {
        case MEDIA_VCARD:
            {
                save = NdefRecord.recordPayload[NdefRecord.recordPayloadSize];
                NdefRecord.recordPayload[NdefRecord.recordPayloadSize] = '\0';
                printf("   vCard:\n%s\r\n", NdefRecord.recordPayload);
                NdefRecord.recordPayload[NdefRecord.recordPayloadSize] = save;
            }
            break;

        case WELL_KNOWN_SIMPLE_TEXT:
            {
                save = NdefRecord.recordPayload[NdefRecord.recordPayloadSize];
                NdefRecord.recordPayload[NdefRecord.recordPayloadSize] = '\0';
                printf("   Text record: %s\r\n", &NdefRecord.recordPayload[NdefRecord.recordPayload[0]+1]);
                NdefRecord.recordPayload[NdefRecord.recordPayloadSize] = save;
            }
            break;

        case WELL_KNOWN_SIMPLE_URI:
            {
                save = NdefRecord.recordPayload[NdefRecord.recordPayloadSize];
                NdefRecord.recordPayload[NdefRecord.recordPayloadSize] = '\0';
                printf("   URI record: %s%s\r\n", ndef_helper_UriHead(NdefRecord.recordPayload[0]), &NdefRecord.recordPayload[1]);
                NdefRecord.recordPayload[NdefRecord.recordPayloadSize] = save;
            }
            break;

        case MEDIA_HANDOVER_WIFI:
            {
                unsigned char index = 26, i;

                printf ("--- Received WIFI credentials:\r\n");
                if ((pNdefRecord[index] == 0x10) && (pNdefRecord[index+1] == 0x0e)) index+= 4;
                while(index < NdefRecord.recordPayloadSize)
                {
                    if (pNdefRecord[index] == 0x10)
                    {
                        if (pNdefRecord[index+1] == 0x45) {printf ("- SSID = "); for(i=0;i<pNdefRecord[index+3];i++) printf("%c", pNdefRecord[index+4+i]); printf ("\r\n");}
                        else if (pNdefRecord[index+1] == 0x03) printf ("- Authenticate Type = %s\r\n", ndef_helper_WifiAuth(pNdefRecord[index+5]));
                        else if (pNdefRecord[index+1] == 0x0f) printf ("- Encryption Type = %s\r\n", ndef_helper_WifiEnc(pNdefRecord[index+5]));
                        else if (pNdefRecord[index+1] == 0x27) {printf ("- Network key = "); for(i=0;i<pNdefRecord[index+3];i++) printf("#"); printf ("\r\n");}
                        index += 4 + pNdefRecord[index+3];
                    }
                    else continue;
                }
            }
            break;

        default:
            printf("   Unsupported NDEF record, cannot parse\r\n");
            break;
        }
        pNdefRecord = GetNextRecord(pNdefRecord);
    }

    printf("\r\n");
}
#endif

#if defined RW_SUPPORT
#ifdef RW_RAW_EXCHANGE
void MIFARE_scenario(void)
{
    bool status;
    unsigned char i;
    unsigned char Resp[256];
    unsigned char RespSize;
    /* Authenticate sector 1 with generic keys */
    unsigned char Auth[] = {0x40, 0x01, 0x10, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};
    /* Read block 4 */
    unsigned char Read[] = {0x10, 0x30, 0x04};
    /* Write block 4 */
    unsigned char WritePart1[] = {0x10, 0xA0, 0x04};
    unsigned char WritePart2[] = {0x10, 0x00, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88, 0x99, 0xaa, 0xbb, 0xcc, 0xdd, 0xee, 0xff};

    /* Authenticate */
    status = NxpNci_ReaderTagCmd(Auth, sizeof(Auth), Resp, &RespSize);
    if((status == NFC_ERROR) || (Resp[RespSize-1] != 0))
    {
        printf(" Authenticate sector %d failed with error 0x%02x\r\n", Auth[1], Resp[RespSize-1]);
        return;
    }
    printf(" Authenticate sector %d succeed\r\n", Auth[1]);

    /* Read block */
    status = NxpNci_ReaderTagCmd(Read, sizeof(Read), Resp, &RespSize);
    if((status == NFC_ERROR) || (Resp[RespSize-1] != 0))
    {
        printf(" Read block %d failed with error 0x%02x\r\n", Read[2], Resp[RespSize-1]);
        return;
    }
    printf(" Read block %d: ", Read[2]); for(i=0;i<RespSize-2;i++) printf("0x%02X ", Resp[i+1]); printf("\r\n");

    /* Write block */
    status = NxpNci_ReaderTagCmd(WritePart1, sizeof(WritePart1), Resp, &RespSize);
    if((status == NFC_ERROR) || (Resp[RespSize-1] != 0))
    {
        printf(" Write block %d failed with error 0x%02x\r\n", WritePart1[2], Resp[RespSize-1]);
        return;
    }
    status = NxpNci_ReaderTagCmd(WritePart2, sizeof(WritePart2), Resp, &RespSize);
    if((status == NFC_ERROR) || (Resp[RespSize-1] != 0))
    {
        printf(" Write block %d failed with error 0x%02x\r\n", WritePart1[2], Resp[RespSize-1]);
        return;
    }
    printf(" Block %d written\r\n", WritePart1[2]);

    /* Read block */
    status = NxpNci_ReaderTagCmd(Read, sizeof(Read), Resp, &RespSize);
    if((status == NFC_ERROR) || (Resp[RespSize-1] != 0))
    {
        printf(" Read failed with error 0x%02x\r\n", Resp[RespSize-1]);
        return;
    }
    printf(" Read block %d: ", Read[2]); for(i=0;i<RespSize-2;i++) printf("0x%02X ", Resp[i+1]); printf("\r\n");
}

void ISO15693_scenario(void)
{
    bool status;
    unsigned char i;
    unsigned char Resp[256];
    unsigned char RespSize;
    unsigned char ReadBlock[] = {0x02, 0x20, 0x08};
    unsigned char WriteBlock[] = {0x02, 0x21, 0x08, 0x11, 0x22, 0x33, 0x44};

    status = NxpNci_ReaderTagCmd(ReadBlock, sizeof(ReadBlock), Resp, &RespSize);
    if((status == NFC_ERROR) || (Resp[RespSize-1] != 0x00))
    {
        printf(" Read block %d failed with error 0x%02x\r\n", ReadBlock[2], Resp[RespSize-1]);
        return;
    }
    printf(" Read block %d: ", ReadBlock[2]); for(i=0;i<RespSize-2;i++) printf("0x%02X ", Resp[i+1]); printf("\r\n");

    /* Write */
    status = NxpNci_ReaderTagCmd(WriteBlock, sizeof(WriteBlock), Resp, &RespSize);
    if((status == NFC_ERROR) || (Resp[RespSize-1] != 0))
    {
        printf(" Write block %d failed with error 0x%02x\r\n", WriteBlock[2], Resp[RespSize-1]);
        return;
    }
    printf(" Block %d written\r\n", WriteBlock[2]);

    /* Read back */
    status = NxpNci_ReaderTagCmd(ReadBlock, sizeof(ReadBlock), Resp, &RespSize);
    if((status == NFC_ERROR) || (Resp[RespSize-1] != 0x00))
    {
        printf(" Read block %d failed with error 0x%02x\r\n", ReadBlock[2], Resp[RespSize-1]);
        return;
    }
    printf(" Read block %d: ", ReadBlock[2]); for(i=0;i<RespSize-2;i++) printf("0x%02X ", Resp[i+1]); printf("\r\n");
}

void PCD_ISO14443_3A_scenario(void)
{
    bool status;
    unsigned char i;
    unsigned char Resp[256];
    unsigned char RespSize;
    /* Read block 4 */
    unsigned char Read[] = {0x30, 0x04};
    /* Write block 4 */
    unsigned char Write[] = {0xA2, 0x04, 0x11, 0x22, 0x33, 0x44};

    /* Read */
    status = NxpNci_ReaderTagCmd(Read, sizeof(Read), Resp, &RespSize);
    if((status == NFC_ERROR) || (Resp[RespSize-1] != 0))
    {
        printf(" Read block %d failed with error 0x%02x\r\n", Read[1], Resp[RespSize-1]);
        return;
    }
    printf(" Read block %d: ", Read[1]); for(i=0;i<RespSize-2;i++) printf("0x%02X ", Resp[i+1]); printf("\r\n");

    /* Write */
    status = NxpNci_ReaderTagCmd(Write, sizeof(Write), Resp, &RespSize);
    if((status == NFC_ERROR) || (Resp[RespSize-1] != 0))
    {
        printf(" Write block %d failed with error 0x%02x\r\n", Write[1], Resp[RespSize-1]);
        return;
    }
    printf(" Block %d written\r\n", Write[1]);

    /* Read back */
    status = NxpNci_ReaderTagCmd(Read, sizeof(Read), Resp, &RespSize);
    if((status == NFC_ERROR) || (Resp[RespSize-1] != 0))
    {
        printf(" Read block %d failed with error 0x%02x\r\n", Read[1], Resp[RespSize-1]);
        return;
    }
    printf(" Read block %d: ", Read[1]); for(i=0;i<RespSize-2;i++) printf("0x%02X ", Resp[i+1]); printf("\r\n");
}

void PCD_ISO14443_4_scenario(void)
{
    bool status;
    unsigned char Resp[256];
    unsigned char RespSize;
    unsigned char SelectPPSE[] = {0x00, 0xA4, 0x04, 0x00, 0x0E, 0x32, 0x50, 0x41, 0x59, 0x2E, 0x53, 0x59, 0x53, 0x2E, 0x44, 0x44, 0x46, 0x30, 0x31, 0x00};

    status = NxpNci_ReaderTagCmd(SelectPPSE, sizeof(SelectPPSE), Resp, &RespSize);
    if((status == NFC_ERROR) || (Resp[RespSize-2] != 0x90) || (Resp[RespSize-1] != 0x00))
    {
        printf(" Select PPSE failed with error %02x %02x\r\n", Resp[RespSize-2], Resp[RespSize-1]);
        return;
    }
    printf(" Select NDEF Application succeed\r\n");
}
#endif

void DisplayCardInfo(NxpNci_RfIntf_t RfIntf)
{
    switch(RfIntf.Protocol)
    {
    case PROT_T1T:
    case PROT_T2T:
    case PROT_T3T:
    case PROT_ISODEP:
        printf(" - POLL MODE: Remote T%dT activated\r\n", RfIntf.Protocol);
        break;
    case PROT_ISO15693:
        printf(" - POLL MODE: Remote ISO15693 card activated\r\n");
        break;
    case PROT_MIFARE:
        printf(" - POLL MODE: Remote MIFARE card activated\r\n");
        break;
    default:
        printf(" - POLL MODE: Undetermined target\r\n");
        return;
    }

    switch(RfIntf.ModeTech) {
    case (MODE_POLL | TECH_PASSIVE_NFCA):
        printf(" SENS_RES = 0x%.2x 0x%.2x", RfIntf.Info.NFC_APP.SensRes[0], RfIntf.Info.NFC_APP.SensRes[1]);
        print_buf("\tNFCID = ", RfIntf.Info.NFC_APP.NfcId, RfIntf.Info.NFC_APP.NfcIdLen);
        if(RfIntf.Info.NFC_APP.SelResLen != 0) printf(" SEL_RES = 0x%.2x\r\n", RfIntf.Info.NFC_APP.SelRes[0]);

    break;

    case (MODE_POLL | TECH_PASSIVE_NFCB):
        if(RfIntf.Info.NFC_BPP.SensResLen != 0) print_buf(" SENS_RES = ", RfIntf.Info.NFC_BPP.SensRes, RfIntf.Info.NFC_BPP.SensResLen);
    break;

    case (MODE_POLL | TECH_PASSIVE_NFCF):
        printf(" Bitrate = %s\r\n", (RfIntf.Info.NFC_FPP.BitRate==1)?"212":"424");
        if(RfIntf.Info.NFC_FPP.SensResLen != 0) print_buf(" SENS_RES = ", RfIntf.Info.NFC_FPP.SensRes, RfIntf.Info.NFC_FPP.SensResLen);
    break;

    case (MODE_POLL | TECH_PASSIVE_15693):
        print_buf(" ID = ", RfIntf.Info.NFC_VPP.ID, sizeof(RfIntf.Info.NFC_VPP.ID));
        printf(" AFI = 0x%.2x\r\n", RfIntf.Info.NFC_VPP.AFI);
        printf(" DSFID = 0x%.2x\r\n", RfIntf.Info.NFC_VPP.DSFID);
    break;

    default:
        break;
    }
}

void Task_Nfc_Reader(NxpNci_RfIntf_t RfIntf)
{
    /* For each discovered cards */
    while(1)
    {
        /* Display detected card information */
        DisplayCardInfo(RfIntf);

        /* What's the detected card type */
        switch(RfIntf.Protocol) {
        case PROT_T1T:
        case PROT_T2T:
        case PROT_T3T:
        case PROT_ISODEP:
#ifndef RW_RAW_EXCHANGE
            /* Process NDEF message read */
            NxpNci_ProcessReaderMode(RfIntf, READ_NDEF);
#ifdef RW_NDEF_WRITING
            RW_NDEF_SetMessage ((unsigned char *) NDEF_MESSAGE, sizeof(NDEF_MESSAGE), *NdefPush_Cb);
            /* Process NDEF message write */
            NxpNci_ProcessReaderMode(RfIntf, WRITE_NDEF);
#endif
#else
            if (RfIntf.Protocol == PROT_ISODEP)
            {
                PCD_ISO14443_4_scenario();
            }
            else if (RfIntf.Protocol == PROT_T2T)
            {
                PCD_ISO14443_3A_scenario();
            }
#endif
            break;

        case PROT_ISO15693:
#ifdef RW_RAW_EXCHANGE
            /* Run dedicated scenario to demonstrate ISO15693 card management */
            ISO15693_scenario();
#endif
            break;

        case PROT_MIFARE:
#ifdef RW_RAW_EXCHANGE
            /* Run dedicated scenario to demonstrate MIFARE card management */
            MIFARE_scenario();
#endif
            break;

        default:
            break;
        }

        /* If more cards (or multi-protocol card) were discovered (only same technology are supported) select next one */
        if(RfIntf.MoreTags) {
            if(NxpNci_ReaderActivateNext(&RfIntf) == NFC_ERROR) break;
        }
        /* Otherwise leave */
        else break;
    }

    /* Wait for card removal */
    NxpNci_ProcessReaderMode(RfIntf, PRESENCE_CHECK);

    printf(" CARD REMOVED\r\n");

    /* Restart discovery loop */
    NxpNci_StopDiscovery();
    NxpNci_StartDiscovery(DiscoveryTechnologies,sizeof(DiscoveryTechnologies));
}
#endif

#if defined CARDEMU_SUPPORT
#ifdef CARDEMU_RAW_EXCHANGE
void PICC_ISO14443_4_scenario (void)
{
    unsigned char OK[] = {0x90, 0x00};
    unsigned char OK1[] = {0x90, 0x01};
    unsigned char OK2[] = {0x90, 0x02};

    unsigned char Cmd[256];
    unsigned char CmdSize;
    bool lock = true;

    while (1)
    {
        if(NxpNci_CardModeReceive(Cmd, &CmdSize) == NFC_SUCCESS)
        {
            if ((CmdSize >= 2) && (Cmd[0] == 0x00) && (Cmd[1] == 0xa4))
            {
                printf("Select AID received\r\n");
                NxpNci_CardModeSend(OK, sizeof(OK));
            }
            else if ((CmdSize >= 4) && (Cmd[0] == 0x00) && (Cmd[1] == 0xb0))
            {
                // process read binary here
            }
            else if ((CmdSize >= 4) && (Cmd[0] == 0x00) && (Cmd[1] == 0xd0))
            {
                // process write binary here
                if(Cmd[3] == 0x00)
                {
                    lock = !lock;
                    lock ? NxpNci_CardModeSend(OK2, sizeof(OK2)) : NxpNci_CardModeSend(OK1, sizeof(OK1));
                }
            }
            else if ((CmdSize >= 3) && (Cmd[0] == 0x00) && (Cmd[1] == 0xfe))
            {
                // return successful termination
                NxpNci_CardModeSend(OK, sizeof(OK));
            }
        }
        else
        {
            printf("End of transaction\r\n");
            return;
        }
    }
}
#endif
#endif

/*
 * main Program
 * @return should never return
 */
int main(void)
{
    uint8_t mode = 0;    
    NxpNci_RfIntf_t RfInterface;

    /* Initialize Board hardware and peripherals */
    BOARD_InitPins();
    BOARD_InitNFCHardware();
    BOARD_BootClockRUN();
    BOARD_InitDebugConsole();
    /* Initialize the timer for delay function */
    Timer_Init();
    /* Initialize the KW40 */
    KW40_UART_Init();  
    /* Initialize the GPIO and DSPI for OLED transfer */
    OLED_Hardware_Init();
    /* Initialize the OLED and set dynamic area */
    OLED_Init();
    OLED_GetImageDimensions(&(splashArea.width), &(splashArea.height), hexiwear_logo_bmp);
    OLED_SetDynamicArea(&splashArea);
    /* Draw the logo image */
    OLED_DrawImage(nfc_logo_bmp);

    InitLeds(kStatus_led_off);
    LED_Set_ON_OFF(ALL_LED, kStatus_led_off);

    /* Interrupt configuration */
    NVIC_SetPriority(BOARD_NXPNCI_IRQ_PORTIRQn, 5);
    EnableIRQ(BOARD_NXPNCI_IRQ_PORTIRQn);
    /* Initialize the Interrupt Service Routine */
    SystemCoreClockUpdate();

    /* Print a note to terminal. */
    PRINTF("\r\n This is HEXIWEAR NFC CLICK example!\r\r\n");

    Timer_Delay_ms(1000);

#ifdef CARDEMU_SUPPORT
    /* Register NDEF message to be sent to remote reader */
    T4T_NDEF_EMU_SetMessage((unsigned char *) NDEF_MESSAGE, sizeof(NDEF_MESSAGE), *NdefPush_Cb);
#endif

#ifdef P2P_SUPPORT
    /* Register NDEF message to be sent to remote peer */
    P2P_NDEF_SetMessage((unsigned char *) NDEF_MESSAGE, sizeof(NDEF_MESSAGE), *NdefPush_Cb);
    /* Register callback for reception of NDEF message from remote peer */
    P2P_NDEF_RegisterPullCallback(*NdefPull_Cb);
#endif

#ifdef RW_SUPPORT
    /* Register callback for reception of NDEF message from remote cards */
    RW_NDEF_RegisterPullCallback(*NdefPull_Cb);
#endif

    /* Set NXPNCI in all modes */
#ifdef CARDEMU_SUPPORT
    mode |= NXPNCI_MODE_CARDEMU;
#endif
#ifdef P2P_SUPPORT
    mode |= NXPNCI_MODE_P2P;
#endif
#ifdef RW_SUPPORT
    mode |= NXPNCI_MODE_RW;
#endif

    /* Open connection to NXPNCI device */
    if (NxpNci_Connect() == NFC_ERROR) 
    {
        printf(" Error: cannot connect to NXPNCI device\r\n");
        while (1);
    }

    if (NxpNci_ConfigureSettings() == NFC_ERROR) 
    {
        printf(" Error: cannot configure NXPNCI settings\r\n");
        while (1);
    }

    if (NxpNci_ConfigureMode(mode) == NFC_ERROR)
    {
        printf(" Error: cannot configure NXPNCI\r\n");
        while (1);
    }

    /* Start Discovery */
    if (NxpNci_StartDiscovery(DiscoveryTechnologies,sizeof(DiscoveryTechnologies)) != NFC_SUCCESS)
    {
        printf(" Error: cannot start discovery\r\n");
        while (1);
    }

    /* Main Loop */
    while (1)
    {
        printf(" WAITING FOR DEVICE DISCOVERY\r\n");

        /* Wait until a peer is discovered */
        NxpNci_WaitForDiscoveryNotification(&RfInterface);

#ifdef CARDEMU_SUPPORT
        /* Is activated from remote T4T ? */
        if ((RfInterface.Interface == INTF_ISODEP) && ((RfInterface.ModeTech & MODE_MASK) == MODE_LISTEN))
        {
            printf(" - LISTEN MODE: Activated from remote Reader\r\n");
#ifndef CARDEMU_RAW_EXCHANGE
            NxpNci_ProcessCardMode(RfInterface);
#else
            PICC_ISO14443_4_scenario();
#endif
            printf(" READER DISCONNECTED\r\n");
        }
        else
#endif

#ifdef P2P_SUPPORT
        /* Is activated from remote T4T ? */
        if (RfInterface.Interface == INTF_NFCDEP)
        {
            if ((RfInterface.ModeTech & MODE_LISTEN) == MODE_LISTEN) printf(" - P2P TARGET MODE: Activated from remote Initiator\r\n");
            else printf(" - P2P INITIATOR MODE: Remote Target activated\r\n");

            /* Process with SNEP for NDEF exchange */
            NxpNci_ProcessP2pMode(RfInterface);

            printf(" PEER LOST\r\n");
        }
        else
#endif
#ifdef RW_SUPPORT
        if ((RfInterface.ModeTech & MODE_MASK) == MODE_POLL)
        {
            Task_Nfc_Reader(RfInterface);
        }
        else
#endif
        {
            printf(" WRONG DISCOVERY\r\n");
        }
    }
}

static void InitLeds(led_status_t status)
{
    LED_RED_INIT(1);
    LED_BLUE_INIT(1);
    LED_GREEN_INIT(1);
}

static void LED_Set_ON_OFF(led_name_t led_name, led_status_t led_status)
{
    if (led_name == RED_LED)
    {
        if (led_status == kStatus_led_on)
        {
            LED_RED_ON();
        }
        else if (led_status == kStatus_led_off)
        {
            LED_RED_OFF();
        }
    }
    else if (led_name == BLUE_LED)
    {
        if (led_status == kStatus_led_on)
        {
            LED_BLUE_ON();
        }
        else if (led_status == kStatus_led_off)
        {
            LED_BLUE_OFF();
        }
    }
    else if (led_name == GREEN_LED)
    {
        if (led_status == kStatus_led_on)
        {
            LED_GREEN_ON();
        }
        else if (led_status == kStatus_led_off)
        {
            LED_GREEN_OFF();
        }
    }
    else
    {
        if (led_status == kStatus_led_on)
        {
            LED_RED_ON();
            LED_BLUE_ON();
            LED_GREEN_ON();
        }
        else if (led_status == kStatus_led_off)
        {
            LED_RED_OFF();
            LED_BLUE_OFF();
            LED_GREEN_OFF();
        }
    }
}
