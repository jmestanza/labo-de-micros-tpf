/*
 * The Clear BSD License
 * Copyright (c) 2015, Freescale Semiconductor, Inc.
 * Copyright 2016-2017 NXP
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted (subject to the limitations in the disclaimer below) provided
 *  that the following conditions are met:
 *
 * o Redistributions of source code must retain the above copyright notice, this list
 *   of conditions and the following disclaimer.
 *
 * o Redistributions in binary form must reproduce the above copyright notice, this
 *   list of conditions and the following disclaimer in the documentation and/or
 *   other materials provided with the distribution.
 *
 * o Neither the name of the copyright holder nor the names of its
 *   contributors may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * NO EXPRESS OR IMPLIED LICENSES TO ANY PARTY'S PATENT RIGHTS ARE GRANTED BY THIS LICENSE.
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
#include "fsl_debug_console.h"
#include "fsl_fxas.h"
#include "board.h"
#include "fsl_timer.h"
#include "screens_resources.h"
#include "fsl_psp27801.h"
#include "fsl_common.h"
#include "pin_mux.h"
#include "fsl_gpio.h"
#include "fsl_port.h"

/*******************************************************************************
 * Definitions
 ******************************************************************************/

/*******************************************************************************
 * Prototypes
 ******************************************************************************/
void BOARD_I2C_ReleaseBus(void);
/*!
 * @brief Read all data from sensor function
 *
 * @param Gx The pointer store x axis gyroscope value
 * @param Gy The pointer store y axis gyroscope value
 * @param Gz The pointer store z axis gyroscope value
 * @note Must calculate g_dataScale before use this function.
 */
static void Sensor_ReadData(int16_t *Gx, int16_t *Gy, int16_t *Gz);

/*******************************************************************************
 * Variables
 ******************************************************************************/
oled_dynamic_area_t splashArea = {.xCrd = 0, .yCrd = 0};
fxas_handle_t g_fxasHandle;
/*******************************************************************************
 * Code
 ******************************************************************************/

static void i2c_release_bus_delay(void)
{
    uint32_t i = 0;
    for (i = 0; i < I2C_RELEASE_BUS_COUNT; i++)
    {
        __NOP();
    }
}

void BOARD_I2C_ReleaseBus(void)
{
    uint8_t i = 0;
    gpio_pin_config_t pin_config;
    port_pin_config_t i2c_pin_config = {0};

    /* Config pin mux as gpio */
    i2c_pin_config.pullSelect = kPORT_PullUp;
    i2c_pin_config.mux = kPORT_MuxAsGpio;

    pin_config.pinDirection = kGPIO_DigitalOutput;
    pin_config.outputLogic = 1U;
    PORT_SetPinConfig(I2C_RELEASE_SCL_PORT, I2C_RELEASE_SCL_PIN, &i2c_pin_config);
    PORT_SetPinConfig(I2C_RELEASE_SDA_PORT, I2C_RELEASE_SDA_PIN, &i2c_pin_config);

    GPIO_PinInit(I2C_RELEASE_SCL_GPIO, I2C_RELEASE_SCL_PIN, &pin_config);
    GPIO_PinInit(I2C_RELEASE_SDA_GPIO, I2C_RELEASE_SDA_PIN, &pin_config);

    /* Drive SDA low first to simulate a start */
    GPIO_PinWrite(I2C_RELEASE_SDA_GPIO, I2C_RELEASE_SDA_PIN, 0U);
    i2c_release_bus_delay();

    /* Send 9 pulses on SCL and keep SDA high */
    for (i = 0; i < 9; i++)
    {
        GPIO_PinWrite(I2C_RELEASE_SCL_GPIO, I2C_RELEASE_SCL_PIN, 0U);
        i2c_release_bus_delay();

        GPIO_PinWrite(I2C_RELEASE_SDA_GPIO, I2C_RELEASE_SDA_PIN, 1U);
        i2c_release_bus_delay();

        GPIO_PinWrite(I2C_RELEASE_SCL_GPIO, I2C_RELEASE_SCL_PIN, 1U);
        i2c_release_bus_delay();
        i2c_release_bus_delay();
    }

    /* Send stop */
    GPIO_PinWrite(I2C_RELEASE_SCL_GPIO, I2C_RELEASE_SCL_PIN, 0U);
    i2c_release_bus_delay();

    GPIO_PinWrite(I2C_RELEASE_SDA_GPIO, I2C_RELEASE_SDA_PIN, 0U);
    i2c_release_bus_delay();

    GPIO_PinWrite(I2C_RELEASE_SCL_GPIO, I2C_RELEASE_SCL_PIN, 1U);
    i2c_release_bus_delay();

    GPIO_PinWrite(I2C_RELEASE_SDA_GPIO, I2C_RELEASE_SDA_PIN, 1U);
    i2c_release_bus_delay();
}
static void Sensor_ReadData(int16_t *Gx, int16_t *Gy, int16_t *Gz)
{
    fxas_data_t fxas_data;

    if (FXAS_ReadSensorData(&g_fxasHandle, &fxas_data) != kStatus_Success)
    {
        PRINTF("Failed to read acceleration data!\r\n");
    }
    /* Get the data from the sensor data structure */
    *Gx = (int16_t)((uint16_t)((uint16_t)fxas_data.gyroXMSB << 8) | (uint16_t)fxas_data.gyroXLSB);
    *Gy = (int16_t)((uint16_t)((uint16_t)fxas_data.gyroYMSB << 8) | (uint16_t)fxas_data.gyroYLSB);
    *Gz = (int16_t)((uint16_t)((uint16_t)fxas_data.gyroZMSB << 8) | (uint16_t)fxas_data.gyroZLSB);
}

int main(void)
{
    fxas_config_t configure; 

    BOARD_InitPins();
    BOARD_BootClockRUN();
    BOARD_I2C_ReleaseBus();
    BOARD_I2C_ConfigurePins();
    BOARD_InitDebugConsole();

    /* Initialize the timer for delay function */
    Timer_Init();

    /* Initialize the GPIO and DSPI for OLED transfer */
    OLED_Hardware_Init(); 
    OLED_Init();
    OLED_GetImageDimensions(&(splashArea.width), &(splashArea.height), hexiwear_logo_bmp);
    OLED_SetDynamicArea(&splashArea);

    OLED_DrawImage(hexiwear_logo_bmp);

    /* Board I2C initialization for sensor. */
    BOARD_Gyroscope_I2C_Init();

    PRINTF("\r\nWelcome to the gyroscope example\r\n");

    /* Init sensor */
    configure.I2C_SendFunc = BOARD_Gyroscope_I2C_Send;
    configure.I2C_ReceiveFunc = BOARD_Gyroscope_I2C_Receive;
    configure.fsrdps = kFXAS_Gfsr_2000DPS;
    configure.odr = kFXAS_Godr_200Hz;
    configure.fifo = kFXAS_FIFO_CircularMode;
    if (FXAS_Init(&g_fxasHandle, &configure) != kStatus_Success)
    {
        PRINTF("\r\nFailed to initialize the sensor device!");
        return -1;
    }

    /* Infinite loops */
    for (;;)
    {
        int16_t Gx = 0;
        int16_t Gy = 0;
        int16_t Gz = 0;

        /* Read sensor data */
        Sensor_ReadData(&Gx, &Gy, &Gz);

        PRINTF("\r\n Gyro X = %d  Y = %d  Z = %d\r\n", Gx, Gy, Gz);

        Timer_Delay_ms(1);
    } 
}
