/*
 * The Clear BSD License
 * Copyright (c) 2015, Freescale Semiconductor, Inc.
 * Copyright 2016-2017 NXP
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted (subject to the limitations in the disclaimer below) provided
 *  that the following conditions are met:
 *
 * o Redistributions of source code must retain the above copyright notice, this list
 *   of conditions and the following disclaimer.
 *
 * o Redistributions in binary form must reproduce the above copyright notice, this
 *   list of conditions and the following disclaimer in the documentation and/or
 *   other materials provided with the distribution.
 *
 * o Neither the name of the copyright holder nor the names of its
 *   contributors may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * NO EXPRESS OR IMPLIED LICENSES TO ANY PARTY'S PATENT RIGHTS ARE GRANTED BY THIS LICENSE.
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "fsl_fxas.h"
/*******************************************************************************
 * Variables
 ******************************************************************************/
/* sensitivity coefficients */
static float gyro_sensCoefs[] = {
    0.0625,    
    0.03125,  
    0.015625,  
    0.0078125 
};

/******************************************************************************
 * Code
 ******************************************************************************/

status_t FXAS_Init(fxas_handle_t *fxas_handle, fxas_config_t *configure)
{
    uint8_t tmp[1] = {0};

    /* Initialize the I2C access function. */
    fxas_handle->I2C_SendFunc = configure->I2C_SendFunc;
    fxas_handle->I2C_ReceiveFunc = configure->I2C_ReceiveFunc;
    /* Check device ID. */
    if(FXAS_ReadReg(fxas_handle, WHO_AM_I_REG, tmp, 1) != kStatus_Success)
    {
        return kStatus_Fail;
    }

    if (tmp[0] != kFXAS_WHO_AM_I_Device_ID)
    {
        return kStatus_Fail;
    }

    /* go to standby */
    if(FXAS_ReadReg(fxas_handle, CTRL_REG1, tmp, 1) != kStatus_Success)
    {
        return kStatus_Fail;
    }
    if(FXAS_WriteReg(fxas_handle, CTRL_REG1, tmp[0] & (uint8_t)~OP_MASK) != kStatus_Success)
    {
        return kStatus_Fail;
    }

    /* Read again to make sure we are in standby mode. */
    if(FXAS_ReadReg(fxas_handle, CTRL_REG1, tmp, 1) != kStatus_Success)
    {
        return kStatus_Fail;
    }
    if ((tmp[0] & OP_MASK) != 0)
    {
        return kStatus_Fail;
    }

    /* Set FIFO */
    if(FXAS_WriteReg(fxas_handle, F_SETUP_REG,  configure->fifo << F_MODE_SHIFT) != kStatus_Success)
    {
        return kStatus_Fail;
    }

    /* Setup the scale range. */
    if(FXAS_WriteReg(fxas_handle, CTRL_REG0, configure->fsrdps) != kStatus_Success)
    {
        return kStatus_Fail;
    }    

    /* Setup data rate */
    if(FXAS_WriteReg(fxas_handle, CTRL_REG1, (configure->odr << DATA_RATE_OFFSET)) != kStatus_Success)
    {
        return kStatus_Fail;
    }  

    /* Setup interrupt configure */
    if(FXAS_WriteReg(fxas_handle, CTRL_REG2, (INT_CFG_DRDY_MASK | INT_EN_DRDY_MASK | IPOL_MASK)) != kStatus_Success)
    {
        return kStatus_Fail;
    } 

    /* Setup rate threshold 
     at max rate threshold = FSR;  rate threshold = THS*FSR/128.
     Enable rate threshold detection on all axes.
    */
    if(FXAS_WriteReg(fxas_handle, RT_CFG_REG, RT_ALLAXES_MASK) != kStatus_Success)
    {
        return kStatus_Fail;
    } 
     /* Unsigned 7-bit THS, set to one-tenth FSR; set clearing debounce counter. */
    if(FXAS_WriteReg(fxas_handle, RT_THS_REG, 0x0D) != kStatus_Success)
    {
        return kStatus_Fail;
    } 
    if(FXAS_WriteReg(fxas_handle, RT_COUNT_REG, 0x4) != kStatus_Success)
    {
        return kStatus_Fail;
    } 

    /* Active mode set */
    if(FXAS_ReadReg(fxas_handle, CTRL_REG1, tmp, 1) != kStatus_Success)
    {
        return kStatus_Fail;
    }
    if(FXAS_WriteReg(fxas_handle, CTRL_REG1, tmp[0] | ACTIVE_MASK) != kStatus_Success)
    {
        return kStatus_Fail;
    }


    /* Read Control register again to ensure we are in active mode */
    if(FXAS_ReadReg(fxas_handle, CTRL_REG1, tmp, 1) != kStatus_Success)
    {
        return kStatus_Fail;
    }

    if ((tmp[0] & ACTIVE_MASK) != ACTIVE_MASK)
    {
        return kStatus_Fail;
    }

    return kStatus_Success;
}

status_t FXAS_ReadSensorData(fxas_handle_t *fxas_handle, fxas_data_t *sensorData)
{
    status_t status = kStatus_Success;
    uint8_t tmp_buff[6] = {0};
    uint8_t i = 0;

    if (!FXAS_ReadReg(fxas_handle, OUT_X_MSB_REG, tmp_buff, 6) == kStatus_Success)
    {
        status = kStatus_Fail;
    }

    for (i = 0; i < 6; i++)
    {
        ((int8_t *)sensorData)[i] = tmp_buff[i];
    }

    return status;
}

status_t FXAS_ReadReg(fxas_handle_t *handle, uint8_t reg, uint8_t *val, uint8_t bytesNumber)
{
    
    assert(handle);
    assert(val);

    if (!handle->I2C_ReceiveFunc)
    {
        return kStatus_Fail;
    }

    return handle->I2C_ReceiveFunc(GYRO_I2C_ADDRESS, reg, 1, val, bytesNumber);
}

status_t FXAS_WriteReg(fxas_handle_t *handle, uint8_t reg, uint8_t val)
{
    assert(handle);

    if (!handle->I2C_SendFunc)
    {
        return kStatus_Fail;
    }

    return handle->I2C_SendFunc(GYRO_I2C_ADDRESS, reg, 1, val);
}

float FXAS_FormatFloat(int16_t input,  fxas_gfsr_t fsrdps)
{
    /* Convert data. */
    return ( float )input * gyro_sensCoefs[(uint8_t)fsrdps];
}
