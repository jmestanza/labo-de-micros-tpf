/*
 * The Clear BSD License
 * Copyright (c) 2017, NXP Semiconductor
 * All rights reserved.
 *
 * 
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted (subject to the limitations in the disclaimer below) provided
 *  that the following conditions are met:
 *
 * o Redistributions of source code must retain the above copyright notice, this list
 *   of conditions and the following disclaimer.
 *
 * o Redistributions in binary form must reproduce the above copyright notice, this
 *   list of conditions and the following disclaimer in the documentation and/or
 *   other materials provided with the distribution.
 *
 * o Neither the name of NXP Semiconductor nor the names of its
 *   contributors may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * NO EXPRESS OR IMPLIED LICENSES TO ANY PARTY'S PATENT RIGHTS ARE GRANTED BY THIS LICENSE.
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

#include <stdlib.h>
#include <string.h>
#include "board.h"
#include "fsl_gpio.h"
#include "fsl_debug_console.h"
#include "screens_resources.h"
#include "fsl_psp27801.h"
#include "spi_flash_driver.h"

#include "fsl_device_registers.h"
#include "clock_config.h"
#include "pin_mux.h"
/*******************************************************************************
 * Definitions
 ******************************************************************************/
#define print_buf(x,y,z)  {int loop; printf(x); for(loop=0;loop<z;loop++) printf("0x%.2x ", y[loop]); printf("\n");}
#define FLASH_RW_DATA_SIZE    1024*4

/*******************************************************************************
 * Prototypes
 ******************************************************************************/
void Board_InitSPIFlashGpio(void);
static void ErrorTrap(void);
/*******************************************************************************
 * Variable
 ******************************************************************************/
oled_dynamic_area_t splashArea = {.xCrd = 0, .yCrd = 0};
char g_Buffer[FLASH_RW_DATA_SIZE];
/*******************************************************************************
 * Code
 ******************************************************************************/

void Board_InitSPIFlashGpio(void)
{
    /* Initialize the GPIO pin. */
    gpio_pin_config_t pin_config;

    pin_config.pinDirection = kGPIO_DigitalOutput;
    pin_config.outputLogic = 1U;
    GPIO_PinInit(BOARD_SPI_FLASH_CS_GPIO, BOARD_SPI_FLASH_CS_GPIO_PIN, &pin_config);   
}
/*
 * main Program
 * @return should never return
 */
int main(void)
{
    uint32_t result;    
    uint8_t vendorId = 0U;
    uint32_t i;
    uint8_t devId[2];
    char data[FLASH_RW_DATA_SIZE];
    uint32_t length;
    uint32_t lenAlign;

    /* Initialize Board hardware and peripherals */
    /* Board pin, clock, debug console init */
    BOARD_InitPins();
    BOARD_BootClockRUN();
    BOARD_InitDebugConsole();
    /* Initialize the GPIO for DPSI for Flash */
    Board_InitSPIFlashGpio();

    /* Initialize the timer for delay function */
    Timer_Init();

    /* Initialize the GPIO and DSPI for OLED transfer */
    OLED_Hardware_Init();
    OLED_Init();
    OLED_GetImageDimensions(&(splashArea.width), &(splashArea.height), hexiwear_logo_bmp);
    OLED_SetDynamicArea(&splashArea);
    /* Draw the logo image */
    OLED_DrawImage(hexiwear_logo_bmp);
    
    /* Initialize the Interrupt Service Routine */
    SystemCoreClockUpdate();

    /* Print a note to terminal. */
    PRINTF("\r\nThis is HEXIWEAR Spi Flash example!\r\n");

    /* SPI initialization. */
    SPI_Init();
 
    result = SPI_Flash_Readid(&vendorId, devId);
    if (result)
    {
        PRINTF("Can not find any SPI Flash device!\r\n");
        ErrorTrap();
    }   

    /* check if it's winbond chip or not */
    if (SPI_FLASH_WINBOND_VENDER_ID == vendorId)
    {
        if (SPI_Flash_Init_Winbond(FLASH_PAGE_SIZE, FLASH_SECTOR_SIZE, 256))
        {
            PRINTF("Failed to init SPI flash chip!\r\n");
            ErrorTrap();
        }
    }
    else
    {
        PRINTF("Not a WinBond SPI flash chip! VID:%x\r\n", vendorId);
        ErrorTrap();
    }

    while (1)
    {
        /* Show guide log */        
        PRINTF("\r\nPlease enter data you want to store in flash with size no larger than FLASH_RW_DATA_SIZE!\r\n ");
        /* Initialize all buffers */
        i = 0;
        memset(&g_Buffer[0], 0, FLASH_RW_DATA_SIZE);
        /* Get char from the terminal */
        char c = GETCHAR();
        while ((c != '\r') && ( c != '\n') && (i < FLASH_RW_DATA_SIZE))
        {
            PUTCHAR(c);
            g_Buffer[i++] = c; 
            c = GETCHAR();
        }
        /* Length calculate */
        length = i;
        lenAlign = ((length + FLASH_SECTOR_SIZE - 1 )/ FLASH_SECTOR_SIZE) * FLASH_SECTOR_SIZE;

        PRINTF("\r\nProgram data to flash ...!\r\n");        
        /* Erase the flash */
        SPI_Flash_Erase_Sector(0, lenAlign);            
        /* Write the data into the flash. */
        result = SPI_Flash_Write(0, length, &g_Buffer[0]);
        if (result)
        {
            PRINTF("\r\nProgram page failed!\r\n");
        }
        else
        {
            PRINTF("\r\nProgram data to flash succeed!\r\n");   
        } 
        /* Read back and verify */
        memset(data, 0, FLASH_RW_DATA_SIZE);
        result = SPI_Flash_Read(0, length, data);
        if (result)
        {
            PRINTF("\r\nFlash read failed!\r\n");
        }
        else
        {
            PRINTF("\r\nRead the data from flash:\r\n");
            PRINTF("\r\n%s\r\n", g_Buffer);
        }
        
        /* compare */
        for (i = 0; i < length; i++)
        {
            if (data[i] != g_Buffer[i])
            {
                PRINTF("Program and verify failed!\r\n");
            }
        }
    }
}

/*Error trap function*/
static void ErrorTrap(void)
{
    PRINTF("\n\rError Occured. Please check the configurations.\n\r");
    while (1)
    {
        ;
    }
}

