Overview
========
The hexiwear_usb_dev_cdc_vcom is a simple demo where hexiwear USB port emulates a USB to serial interface and transfer some random data that user will can visualize in the Hyperterminal.

When you succeed to emulated a virtual com device and you are required to install CDC driver, please follow steps below to install CDC driver:
1.Open the computer management, Find the "MCU VIRTUL COM DEMO" in Other devices. Right click "Update Driver Software..."
2. Choose "Browse my computer for driver software"
3. Navigate to your CDC driver location.
<install_dir>\boards\<board>\demo_apps\usb_dev_cdc_vcom\inf
4. Press "Next"
5. Ignore the warning and press "Yes"
6. Now the CDC driver should be installed successfully.

Toolchain supported
===================
- Keil MDK 5.24a
- IAR embedded Workbench 8.22.2
- GCC ARM Embedded 7-2017-q4-major
- MCUXpresso10.2.0

Hardware requirements
=====================
- Mini/micro USB cable
- USB A to micro AB cable
- Hexiwear Main board/Hexiwear Docking Station board
- Personal Computer

Board settings
==============


Prepare the Demo
================
1.  Connect a USB cable between the host PC and the OpenSDA USB port on the target board.
2.  Open a serial terminal with the following settings:
    - 115200 baud rate
    - 8 data bits
    - No parity
    - One stop bit
    - No flow control
3.  Download the program to the target board.
4.  Either press the reset button on your board or launch the debugger in your IDE to begin running the demo.
5. Connect a USB cable between the PC host and the USB device port on hexiwear main board.

Running the demo
================
When demo has run on Hexiwear boards, a COM port is enumerated in the Device Manager.
If it prompts for the CDC driver installation. Follow above steps to install the CDC driver. The debug console will print some information
in the terminal window like below:
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

This is hexiwear usb device cdc virtual com demo!
USB device init success

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Open the COM port in the terminal tool, such as Tera Term or Putty.
Type characters. The characters are echoed back from the COM port.
Customization options
=====================

