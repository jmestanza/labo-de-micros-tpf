#ifndef _PIN_MUX_H_
#define _PIN_MUX_H_


/*******************************************************************************
 * Definitions
 ******************************************************************************/

/*! @brief Direction type  */
typedef enum _pin_mux_direction
{
  kPIN_MUX_DirectionInput = 0U,         /* Input direction */
  kPIN_MUX_DirectionOutput = 1U,        /* Output direction */
  kPIN_MUX_DirectionInputOrOutput = 2U  /* Input or output direction */
} pin_mux_direction_t;

/*!
 * @addtogroup pin_mux
 * @{
 */

/*******************************************************************************
 * API
 ******************************************************************************/

#if defined(__cplusplus)
extern "C" {
#endif

/*!
 * @brief Calls initialization functions.
 *
 */
void BOARD_InitBootPins(void);

/* PORTB17 (coord E9), ExtConn[7]/UART0_TX */
#define BOARD_UART0_TX_PERIPHERAL                                          UART0   /*!< Device name: UART0 */
#define BOARD_UART0_TX_SIGNAL                                                 TX   /*!< UART0 signal: TX */
#define BOARD_UART0_TX_PIN_NAME                                         UART0_TX   /*!< Pin name */
#define BOARD_UART0_TX_LABEL                               "ExtConn[7]/UART0_TX"   /*!< Label */
#define BOARD_UART0_TX_NAME                                           "UART0_TX"   /*!< Identifier name */

/* PORTB22 (coord F8), OLED1[15]/OLED_SDI */
#define BOARD_OLED_SPI_SDI_PERIPHERAL                                       SPI2   /*!< Device name: SPI2 */
#define BOARD_OLED_SPI_SDI_SIGNAL                                           SOUT   /*!< SPI2 signal: SOUT */
#define BOARD_OLED_SPI_SDI_PIN_NAME                                    SPI2_SOUT   /*!< Pin name */
#define BOARD_OLED_SPI_SDI_LABEL                            "OLED1[15]/OLED_SDI"   /*!< Label */
#define BOARD_OLED_SPI_SDI_NAME                                   "OLED_SPI_SDI"   /*!< Identifier name */

/* PORTB21 (coord F9), OLED[14]/OLED_SCK */
#define BOARD_OLED_SPI_SCLK_PERIPHERAL                                      SPI2   /*!< Device name: SPI2 */
#define BOARD_OLED_SPI_SCLK_SIGNAL                                           SCK   /*!< SPI2 signal: SCK */
#define BOARD_OLED_SPI_SCLK_PIN_NAME                                    SPI2_SCK   /*!< Pin name */
#define BOARD_OLED_SPI_SCLK_LABEL                            "OLED[14]/OLED_SCK"   /*!< Label */
#define BOARD_OLED_SPI_SCLK_NAME                                 "OLED_SPI_SCLK"   /*!< Identifier name */

/* PORTE6 (coord F3), OLED1[7]/OLED_RST */
#define BOARD_OLED_RST_GPIO                                                GPIOE   /*!< GPIO device name: GPIOE */
#define BOARD_OLED_RST_PORT                                                PORTE   /*!< PORT device name: PORTE */
#define BOARD_OLED_RST_GPIO_PIN                                               6U   /*!< PORTE pin index: 6 */
#define BOARD_OLED_RST_PIN_NAME                                             PTE6   /*!< Pin name */
#define BOARD_OLED_RST_LABEL                                 "OLED1[7]/OLED_RST"   /*!< Label */
#define BOARD_OLED_RST_NAME                                           "OLED_RST"   /*!< Identifier name */

/* PORTC13 (coord A6), U11[3]/OLED_PWR */
#define BOARD_OLED_PWR_GPIO                                                GPIOC   /*!< GPIO device name: GPIOC */
#define BOARD_OLED_PWR_PORT                                                PORTC   /*!< PORT device name: PORTC */
#define BOARD_OLED_PWR_GPIO_PIN                                              13U   /*!< PORTC pin index: 13 */
#define BOARD_OLED_PWR_PIN_NAME                                            PTC13   /*!< Pin name */
#define BOARD_OLED_PWR_LABEL                                   "U11[3]/OLED_PWR"   /*!< Label */
#define BOARD_OLED_PWR_NAME                                           "OLED_PWR"   /*!< Identifier name */

/* PORTD15 (coord E1), OLED1[8]/OLED_DC */
#define BOARD_OLED_DC_GPIO                                                 GPIOD   /*!< GPIO device name: GPIOD */
#define BOARD_OLED_DC_PORT                                                 PORTD   /*!< PORT device name: PORTD */
#define BOARD_OLED_DC_GPIO_PIN                                               15U   /*!< PORTD pin index: 15 */
#define BOARD_OLED_DC_PIN_NAME                                             PTD15   /*!< Pin name */
#define BOARD_OLED_DC_LABEL                                   "OLED1[8]/OLED_DC"   /*!< Label */
#define BOARD_OLED_DC_NAME                                             "OLED_DC"   /*!< Identifier name */

/* PORTB20 (coord F10), OLED1[9]/OLED_CS */
#define BOARD_OLED_CS_GPIO                                                 GPIOB   /*!< GPIO device name: GPIOB */
#define BOARD_OLED_CS_PORT                                                 PORTB   /*!< PORT device name: PORTB */
#define BOARD_OLED_CS_GPIO_PIN                                               20U   /*!< PORTB pin index: 20 */
#define BOARD_OLED_CS_PIN_NAME                                             PTB20   /*!< Pin name */
#define BOARD_OLED_CS_LABEL                                   "OLED1[9]/OLED_CS"   /*!< Label */
#define BOARD_OLED_CS_NAME                                             "OLED_CS"   /*!< Identifier name */

/* PORTE24 (coord H5), U4[42]/UART4_TX */
#define BOARD_UART4_TX_PERIPHERAL                                          UART4   /*!< Device name: UART4 */
#define BOARD_UART4_TX_SIGNAL                                                 TX   /*!< UART4 signal: TX */
#define BOARD_UART4_TX_PIN_NAME                                         UART4_TX   /*!< Pin name */
#define BOARD_UART4_TX_LABEL                                   "U4[42]/UART4_TX"   /*!< Label */
#define BOARD_UART4_TX_NAME                                           "UART4_TX"   /*!< Identifier name */


/*!
 * @brief Configures pin routing and optionally pin electrical features.
 *
 */
void BOARD_InitPins(void);


/*!
 * @brief Configures pin routing and optionally pin electrical features.
 *
 */
void BOARD_I2C_ConfigurePins(void);

#if defined(__cplusplus)
}
#endif

/*!
 * @}
 */
#endif /* _PIN_MUX_H_ */

/*******************************************************************************
 * EOF
 ******************************************************************************/
