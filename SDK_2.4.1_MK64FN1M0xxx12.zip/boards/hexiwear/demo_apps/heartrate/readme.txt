Overview
========
The heart rate demo demonstrates basic usage of the on-board heart rate sensor.


Toolchain supported
===================
- Keil MDK 5.24a
- IAR embedded Workbench 8.22.2
- GCC ARM Embedded 7-2017-q4-major
- MCUXpresso10.2.0

Hardware requirements
=====================
- Mini/Micro USB cable
- Hexiwear Main board
- Personal Computer

Board settings
==============
No special settings are required.

Prepare the Demo
================
1.  Connect a USB cable between the host PC and the OpenSDA USB port on the target board.
2.  Open a serial terminal with the following settings:
    - 115200 baud rate
    - 8 data bits
    - No parity
    - One stop bit
    - No flow control
3.  Download the program to the target board.
4.  Either press the reset button on your board or launch the debugger in your IDE to begin running the demo.

Running the demo
================

When the example runs successfully, you can see "Heart rate" word and
a heart rate icon image on the hexiwear watch and you will see below
log on the terminal

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

This is hexiwear heartrate demo! 

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Please put your finger on the sensor which is under the watch and press the "Start" button on the watch to sampling data. you can see the similar information from the terminal as shown below. 

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Start Sampling Data!

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


The heart rate sensor will sampled data and calculated those data to a heart rate bmp value every once a while. The heart rate will update the bmp value to the screen once the bmp value is changed. you can see the similar information from the terminal as shown below.

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Sending Calculated Data!

Sending Calculated Data!

Sending Calculated Data!
...
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Press the "Stop" button on watch will stop the heart rate sampling,
you can see the similar information from the terminal as shown below. 
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Stop Sampling Data!

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Customization options
=====================

