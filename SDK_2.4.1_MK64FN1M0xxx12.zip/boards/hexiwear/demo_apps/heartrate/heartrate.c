/*
 * The Clear BSD License
 * Copyright (c) 2017, NXP Semiconductors, Inc.
* All rights reserved.
*
 * 
* Redistribution and use in source and binary forms, with or without modification,
* are permitted (subject to the limitations in the disclaimer below) provided
*  that the following conditions are met:
*
* o Redistributions of source code must retain the above copyright notice, this list
*   of conditions and the following disclaimer.
*
* o Redistributions in binary form must reproduce the above copyright notice, this
*   list of conditions and the following disclaimer in the documentation and/or
*   other materials provided with the distribution.
*
* o Neither the name of the copyright holder nor the names of its
*   contributors may be used to endorse or promote products derived from this
*   software without specific prior written permission.
*
* NO EXPRESS OR IMPLIED LICENSES TO ANY PARTY'S PATENT RIGHTS ARE GRANTED BY THIS LICENSE.
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
* ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
* ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
* ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
* SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#include "board.h"
#include "clock_config.h"
#include "fsl_debug_console.h"
#include "fsl_device_registers.h"
#include "fsl_max.h"
#include "fsl_psp27801.h"
#include "heartrate_driver.h"
#include "pin_mux.h"
#include "screens_resources.h"
#include "uart_kw40_transfer.h"

#include "fsl_common.h"
#include "fsl_gpio.h"
#include "fsl_port.h"
/*******************************************************************************
 * Definitions
 ******************************************************************************/

/*******************************************************************************
 * Prototypes
 ******************************************************************************/
void BOARD_I2C_ReleaseBus(void);

/*******************************************************************************
 * Variables
 ******************************************************************************/
/* FMAX device address */
oled_dynamic_area_t splashArea = {.xCrd = 0, .yCrd = 0};
extern volatile touch_type_t pressedTouch;
/*******************************************************************************
 * Code
 ******************************************************************************/
static void BOARD_EnableHeartRatePower(void)
{
    gpio_pin_config_t pin_config;

    pin_config.pinDirection = kGPIO_DigitalOutput;
    pin_config.outputLogic = 0U;
    GPIO_PinInit(GPIOA, 29, &pin_config);    
    
    pin_config.pinDirection = kGPIO_DigitalOutput;
    pin_config.outputLogic = 1U;
    GPIO_PinInit(GPIOA, 29, &pin_config);
    
    pin_config.pinDirection = kGPIO_DigitalOutput;
    pin_config.outputLogic = 0U;
    GPIO_PinInit(GPIOB, 12, &pin_config);
}


static void i2c_release_bus_delay(void)
{
    uint32_t i = 0;
    for (i = 0; i < HEARTRATE_I2C_RELEASE_BUS_COUNT; i++)
    {
        __NOP();
    }
}

void BOARD_I2C_ReleaseBus(void)
{
    uint8_t i = 0;
    gpio_pin_config_t pin_config;
    port_pin_config_t i2c_pin_config = {0};

    /* Config pin mux as gpio */
    i2c_pin_config.pullSelect = kPORT_PullUp;
    i2c_pin_config.mux = kPORT_MuxAsGpio;

    pin_config.pinDirection = kGPIO_DigitalOutput;
    pin_config.outputLogic = 1U;
    PORT_SetPinConfig(HEARTRATE_I2C_RELEASE_SCL_PORT, HEARTRATE_I2C_RELEASE_SCL_PIN, &i2c_pin_config);
    PORT_SetPinConfig(HEARTRATE_I2C_RELEASE_SDA_PORT, HEARTRATE_I2C_RELEASE_SDA_PIN, &i2c_pin_config);

    GPIO_PinInit(HEARTRATE_I2C_RELEASE_SCL_GPIO, HEARTRATE_I2C_RELEASE_SCL_PIN, &pin_config);
    GPIO_PinInit(HEARTRATE_I2C_RELEASE_SDA_GPIO, HEARTRATE_I2C_RELEASE_SDA_PIN, &pin_config);

    /* Drive SDA low first to simulate a start */
    GPIO_PinWrite(HEARTRATE_I2C_RELEASE_SDA_GPIO, HEARTRATE_I2C_RELEASE_SDA_PIN, 0U);
    i2c_release_bus_delay();

    /* Send 9 pulses on SCL and keep SDA high */
    for (i = 0; i < 9; i++)
    {
        GPIO_PinWrite(HEARTRATE_I2C_RELEASE_SCL_GPIO, HEARTRATE_I2C_RELEASE_SCL_PIN, 0U);
        i2c_release_bus_delay();

        GPIO_PinWrite(HEARTRATE_I2C_RELEASE_SDA_GPIO, HEARTRATE_I2C_RELEASE_SDA_PIN, 1U);
        i2c_release_bus_delay();

        GPIO_PinWrite(HEARTRATE_I2C_RELEASE_SCL_GPIO, HEARTRATE_I2C_RELEASE_SCL_PIN, 1U);
        i2c_release_bus_delay();
        i2c_release_bus_delay();
    }

    /* Send stop */
    GPIO_PinWrite(HEARTRATE_I2C_RELEASE_SCL_GPIO, HEARTRATE_I2C_RELEASE_SCL_PIN, 0U);
    i2c_release_bus_delay();

    GPIO_PinWrite(HEARTRATE_I2C_RELEASE_SDA_GPIO, HEARTRATE_I2C_RELEASE_SDA_PIN, 0U);
    i2c_release_bus_delay();

    GPIO_PinWrite(HEARTRATE_I2C_RELEASE_SCL_GPIO, HEARTRATE_I2C_RELEASE_SCL_PIN, 1U);
    i2c_release_bus_delay();

    GPIO_PinWrite(HEARTRATE_I2C_RELEASE_SDA_GPIO, HEARTRATE_I2C_RELEASE_SDA_PIN, 1U);
    i2c_release_bus_delay();
}
/*!
 * @brief Main function
 */
int main(void)
{
    status_t status;
    max_handle_t maxHandle;
    bool start = false;
    uint8_t size = 0;
    uint8_t dataBuffer[MAXIM_FIFO_DEPTH * MAXIM_BYTES_PER_ADC_VALUE] = {0};
    max_config_t config;

    BOARD_InitPins();
    BOARD_BootClockRUN();
    BOARD_I2C_ReleaseBus();
    BOARD_I2C_ConfigurePins();
    BOARD_InitDebugConsole();
    BOARD_EnableHeartRatePower();
    BOARD_HeartRate_I2C_Init();
    /* Initialize the timer for delay function */
    Timer_Init();
    /* Initialize the KW40 */
    KW40_UART_Init();
    /* Initialize the KW40 uart for communication */
    PRINTF("\r\nThis is hexiwear heartrate demo!\r\n");

    /* Initialize the GPIO and DSPI for OLED transfer */
    OLED_Hardware_Init();
    /* Initialize the OLED and set the dynamic area */
    OLED_Init();
    OLED_GetImageDimensions(&(splashArea.width), &(splashArea.height), heartRate_screen_bmp);
    OLED_SetDynamicArea(&splashArea);
    OLED_DrawImage(heartRate_screen_bmp);

    /* HeartRate Gui Initialize. */
    HeartRate_Init();

    /* Initialize heart rate sensor */
    config.I2C_SendFunc = BOARD_HeartRate_I2C_Send;
    config.I2C_ReceiveFunc = BOARD_HeartRate_I2C_Receive;
    config.mode = kMAX_MultiLedMode;
    config.pulsewidth = kMAX_PW_411US_18Bits;
    config.samples = kMAX_SR_100Hz;
    config.adcRange = kMAX_AdcRge_02;
    if (MAX_Init(&maxHandle, &config) != kStatus_Success)
    {
        PRINTF("\r\nSensor Initialization failed!\r\n");
        return -1;
    }

    while (1)
    {
        if (pressedTouch == touch_right)
        {
            if (!start)
            {
                start = true;
                HeartRate_ResumeGUI();
                PRINTF("\r\nStart Sampling Data!\r\n");
            }
            else
            {
                HeartRate_PauseGUI();
                start = false;
                PRINTF("\r\nStop Sampling Data!\r\n");
            }
            pressedTouch = touch_invalid;
        }

        if (start)
        {
            status = MAX_ReadSensorData(&maxHandle, &dataBuffer[0], &size);
            if (status == kStatus_Success)
            {
                /* Process data */
                HeartRate_Process(&dataBuffer[0], size, NULL);
            }
            else
            {
                PRINTF("\r\nReading Sensor failed\r\n");
            }
            /* Read data from sensor */
            if (g_heartUpdated)
            {
                PRINTF("\r\nSending Calculated Data!\r\n");
                HeartRate_UpateGUI();
                g_heartUpdated = false;
            }
        }
    }
}
