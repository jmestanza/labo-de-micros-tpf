Overview
========
The hexiwear_usb_dev_msc_sdcard is a simple demo where hexiwear USB port emulates USB as a MSD device.

In this demo, board will read the humidity from HTU21D, and store the data in the txt file on the SD card.
If users plug the USB on HEXIWEAR board to the PC, the hexiwear board will emulates as a MSD device.
The data of the humidity can be got in the "Removalbe Disk" device.
And when the USB port was pluged in, to protect the SD card, the demo will stop reading data and stop writing
data to the SD card.

Toolchain supported
===================
- Keil MDK 5.24a
- IAR embedded Workbench 8.22.2
- GCC ARM Embedded 7-2017-q4-major
- MCUXpresso10.2.0

Hardware requirements
=====================
- Mini/micro USB cable
- USB A to micro AB cable
- Hexiwear Main board/Hexiwear Docking Station board
- Personal Computer
- SDCard.

Board settings
==============
Plug in the Hexiwear Main board to the Hexiwear Docking Station board, and plug the SDCard
to the Hexiwear Docking Station board.

NOTE: the demo will detect the SD card insert by DATA3 pin, some SD card may can't been detected by the demo.
      In this case, you can change a new SD card or change the code in fsl_pinmux.c to set the SDHC0_3 pin to pull up,
	  if you have done this, demo may run successfully, but the SD card detect function will not work well.
	  This may cause some damage to your device, we don't suggest doing this.
	  
	  Besides, the value of humidity printed by debug console maybe not very same with the data value stored in SD card, 
	  brcause the data printed by debug console will do decimals to round up and round down, but the data stored 
	  in SD card will discard this function. For example, if a float data is 32.096%, data print by debug console will 
	  be 32.10%, but data stored in SD card is 32.09%.

Prepare the Demo
================
1.  Connect a USB cable between the host PC and the OpenSDA USB port on the target board.
2.  Open a serial terminal with the following settings:
    - 115200 baud rate
    - 8 data bits
    - No parity
    - One stop bit
    - No flow control
3.  Download the program to the target board.
4.  Either press the reset button on your board or launch the debugger in your IDE to begin running the demo.
5. Connect a USB cable between the PC host and the USB device port on hexiwear main board.

Running the demo
================
When demo has run on Hexiwear boards, Please input y or n to choose if making file system on the SDcard.
Select y will delete all the data on the SDcard, If a file system has already existed on the SD card, there
is no need to make file system again. When some data printed by the debug console, connect the USB to the PC host,
Board will stop reading data, and data can be get from the "Removeable Disk", /HUMIDITY/DATA.TXT.
Note: If you plug the USB to PC before demo starts, the data in "Removeable Disk" may be empty.
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
This is HEXIWEAR USB MSD demo, when pluging in the USB to host device,
HEXIWEAR board will be treat as MSD device! The humidity data will be
stored in the txt file. The data will be stored every 5 seconds.
If the USB host was pluged in, demo will stop reading the humidity data!

Initialized the OLED device successfully!

Initialized the humidity sensor successfully.

Start to initialize the SD card....
  Card inserted.
Initialized the SD card successfully!

Start to initialize the file system....
  Attention: Making file system will delete all the data on the card!
  If a file system already exists on the card, no need to make it again!
  Please select if make file system on the board? y for yes and n for no....

  Make file system......The time may be long if the card capacity is big.
  Make file system successfully.
  Create directory to save the humidity data......
  Create file to save the humidity data......
Initialized file system successfully!

Initialize the USB device successfully.

Start to read data from sensor and store them to the SD card....
  The current humidity value is: 34.06%.
  The current humidity value is: 33.66%.
  The current humidity value is: 33.40%.
USB host has pluged in, stop reading data.
USB host has removed! Resume reading data!
  The current humidity value is: 32.21%.
  The current humidity value is: 32.19%.
  The current humidity value is: 31.96%.
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Customization options
=====================

