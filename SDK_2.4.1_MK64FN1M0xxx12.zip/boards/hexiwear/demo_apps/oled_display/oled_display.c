/*
 * The Clear BSD License
 * Copyright (c) 2016, NXP Semiconductors, Inc.
* All rights reserved.
*
 *
 * Redistribution and use in source and binary forms, with or without modification,
* are permitted (subject to the limitations in the disclaimer below) provided
 * that the following conditions are met:
*
* o Redistributions of source code must retain the above copyright notice, this list
*   of conditions and the following disclaimer.
*
* o Redistributions in binary form must reproduce the above copyright notice, this
*   list of conditions and the following disclaimer in the documentation and/or
*   other materials provided with the distribution.
*
* o Neither the name of the copyright holder nor the names of its
*   contributors may be used to endorse or promote products derived from this
*   software without specific prior written permission.
*
* NO EXPRESS OR IMPLIED LICENSES TO ANY PARTY'S PATENT RIGHTS ARE GRANTED BY THIS LICENSE.
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
* ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
* ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
* ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
* SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#include "board.h"
#include "clock_config.h"
#include "fsl_debug_console.h"
#include "fsl_device_registers.h"
#include "fsl_psp27801.h"
#include "gui_resources.h"
#include "pin_mux.h"
#include "screens_resources.h"

/*******************************************************************************
 * Definitions
 ******************************************************************************/


/*******************************************************************************
 * Prototypes
 ******************************************************************************/

/*******************************************************************************
 * Variables
 ******************************************************************************/
oled_dynamic_area_t splashArea = {.xCrd = 0, .yCrd = 60};
/*******************************************************************************
 * Code
 ******************************************************************************/


/*!
 * @brief Main function
 */
int main(void)
{
    const char text[18] = "Hello World";
    oled_text_properties_t textProperties = {
        guiFont_13x14_Regular,  /* .textProperties.font */
        OLED_COLOR_BLUE_1,      /* .textProperties.fontColor*/
        OLED_TEXT_ALIGN_CENTER, /* .textProperties.alignParam*/
        NULL                    /* .textProperties.background*/
    };

    BOARD_InitPins();
    BOARD_BootClockRUN();
    BOARD_InitDebugConsole();
    /* Initialize the timer for delay function */
    Timer_Init();

    PRINTF("This is hexiwear oled display demo!\r\n");

    /* Initialize the GPIO and DSPI for OLED transfer */
    OLED_Hardware_Init();
    /* Initialize the OLED */
    OLED_Init();

    OLED_FillScreen(OLED_COLOR_BLACK);
    /* Draw the NXP logo image on OLED screen */
    OLED_GetImageDimensions(&(splashArea.width), &(splashArea.height), nxp_banner_bmp);
    OLED_SetDynamicArea(&splashArea);
    OLED_DrawImage(nxp_banner_bmp);

    OLED_SetTextProperties(&textProperties);

    splashArea.xCrd = 15;
    splashArea.yCrd = 10;
    splashArea.width = OLED_GetTextWidth((const uint8_t *)&text);
    splashArea.height = 16;
    OLED_SetDynamicArea(&splashArea);
    OLED_DrawText((const uint8_t *)&text);

    PRINTF("Please see the oled display on the hexiwear screen!\r\n");

    while (1)
    {
    }
}
