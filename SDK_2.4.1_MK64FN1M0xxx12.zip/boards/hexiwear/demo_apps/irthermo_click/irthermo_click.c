/*
 * The Clear BSD License
 * Copyright (c) 2016, NXP Semiconductors, Inc.
* All rights reserved.
*
 *
 * Redistribution and use in source and binary forms, with or without modification,
* are permitted (subject to the limitations in the disclaimer below) provided
 * that the following conditions are met:
*
* o Redistributions of source code must retain the above copyright notice, this list
*   of conditions and the following disclaimer.
*
* o Redistributions in binary form must reproduce the above copyright notice, this
*   list of conditions and the following disclaimer in the documentation and/or
*   other materials provided with the distribution.
*
* o Neither the name of the copyright holder nor the names of its
*   contributors may be used to endorse or promote products derived from this
*   software without specific prior written permission.
*
* NO EXPRESS OR IMPLIED LICENSES TO ANY PARTY'S PATENT RIGHTS ARE GRANTED BY THIS LICENSE.
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
* ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
* ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
* ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
* SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#include "fsl_device_registers.h"
#include "fsl_debug_console.h"
#include "fsl_i2c.h"
#include "screens_resources.h"
#include "fsl_psp27801.h"
#include "clock_config.h"
#include "pin_mux.h"
#include "board.h"
#include "stdio.h"

/*******************************************************************************
 * Definitions
 ******************************************************************************/

/* The UART to use for debug messages. */
#define BOARD_DEBUG_UART_TYPE DEBUG_CONSOLE_DEVICE_TYPE_UART
#define BOARD_DEBUG_UART_BASEADDR (uint32_t) UART0
#define BOARD_DEBUG_UART_CLK_FREQ CLOCK_GetCoreSysClkFreq()

#ifndef BOARD_DEBUG_UART_BAUDRATE
#define BOARD_DEBUG_UART_BAUDRATE 115200
#endif /* BOARD_DEBUG_UART_BAUDRATE */

#define DSPI_OLED_TRANSFER_BAUDRATE 8000000
#define DSPI_MASTER_CLK_FREQ CLOCK_GetFreq(DSPI0_CLK_SRC)
#define AMB_TEMP (0x06)
#define OBJ_TEMP (0x07)
#define FAHRENHEIT (0x01)
#define CELSIUS (0x02)

/*******************************************************************************
 * Prototypes
 ******************************************************************************/
static float ReadTemperature(uint8_t source);
static float ReadSensor(uint8_t tempSource);

/*******************************************************************************
 * Variables
 ******************************************************************************/
oled_dynamic_area_t splashArea = {.xCrd = 0, .yCrd = 0};
oled_dynamic_area_t tempTextArea = {.xCrd = 0, .yCrd = 75, .width = 73, .height = 16};

oled_dynamic_area_t tempValArea = {.xCrd = 73, .yCrd = 75, .width = 23, .height = 16};

oled_text_properties_t tempTextProperties = {.font = guiFont_10x10_Regular,
                                             .fontColor = GUI_COLOR_WHITE,
                                             .alignParam = OLED_TEXT_ALIGN_CENTER,
                                             .background = NULL};
static uint8_t tempText[] = "Temperature:";
static uint8_t tempValText[] = "000";
static uint8_t temp_format = FAHRENHEIT;
/*******************************************************************************
 * Code
 ******************************************************************************/
void Hardware_I2C_Init(void)
{
    i2c_master_config_t masterConfig;

    /*
       * masterConfig.baudRate_Bps = 100000U;
       * masterConfig.enableStopHold = false;
       * masterConfig.glitchFilterWidth = 0U;
       * masterConfig.enableMaster = true;
       */
    I2C_MasterGetDefaultConfig(&masterConfig);
    I2C_MasterInit(BOARD_IRTHERMO_I2C_MASTER_BASEADDR, &masterConfig, BOARD_IRTHERMO_I2C_MASTER_CLK_FREQ);
}


static float ReadSensor(uint8_t tempSource)
{
    status_t status;
    uint8_t tempVal[2];
    i2c_master_transfer_t masterXfer;

    masterXfer.slaveAddress = BOARD_IRTHERMO_I2C_MASTER_SLAVE_ADDR_7BIT;
    masterXfer.direction = kI2C_Read;
    masterXfer.subaddress = tempSource;
    masterXfer.subaddressSize = sizeof(tempSource);
    masterXfer.data = tempVal;
    masterXfer.dataSize = 2;
    masterXfer.flags = kI2C_TransferDefaultFlag;

    status = I2C_MasterTransferBlocking(BOARD_IRTHERMO_I2C_MASTER_BASEADDR, &masterXfer);

    if (kStatus_Success != status)
    {
        return (float)-1;
    }
    else
    {
        return (float)(((uint16_t)tempVal[1] << 8) | tempVal[0]);
    }
}

static float ReadTemperature(uint8_t source)
{
    float temp = ReadSensor(source);

    if (-1 != temp)
    {
        if (FAHRENHEIT == temp_format)
        {
            /* Convert result in FAHRENHEIT degrees */
            temp = ((temp * 0.02f) - 273.15f) * 9.0f / 5 + 32;
        }
        else if (CELSIUS == temp_format)
        {
            /* Convert result in Celsius degrees */
            temp = (temp * 0.02f) - 273.15f;
        }
        else
        {
            temp = 0;
        }
    }

    return temp;
}

/*!
 * @brief Main function
 */
int main(void)
{
    BOARD_InitPins();
    BOARD_BootClockRUN();
    BOARD_InitDebugConsole();
    /* Initialize the I2C for tempreture */
    Hardware_I2C_Init();
    /* Initialize the timer for delay function */
    Timer_Init();

    PRINTF("This is Hexiwear irthermo click demos!\r\n");
    PRINTF("This demo will read out the tempreature every 5 seconds.\r\n\r\n");

    /* Initialize the GPIO and DSPI for OLED transfer */
    OLED_Hardware_Init();
    /* Initialize the OLED and set dynamic area */
    OLED_Init();
    OLED_GetImageDimensions(&(splashArea.width), &(splashArea.height), hexiwear_logo_bmp);
    OLED_SetDynamicArea(&splashArea);
    /* Draw the logo image */
    OLED_DrawImage(irthermo_logo_bmp);
    /* Set the text properties and dynamic area */
    OLED_SetTextProperties(&tempTextProperties);
    OLED_SetDynamicArea(&tempTextArea);
    OLED_DrawText(tempText);

    while (1)
    {
        float tempValue = ReadTemperature(OBJ_TEMP);

        if (0 != tempValue)
        {
            volatile int16_t tempIntVal = (int16_t)tempValue;

            snprintf((char *)tempValText, 4, "%3d", tempIntVal);
            OLED_SetDynamicArea(&tempValArea);
            OLED_DrawText(tempValText);
            PRINTF("Current temptreature is : %s(Fahrenheit).\r\n", tempValText);
        }

        Timer_Delay_ms(5000);
    }
}
