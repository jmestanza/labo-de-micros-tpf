/*
 * The Clear BSD License
 * Copyright (c) 2016, NXP Semiconductors, Inc.
* All rights reserved.
*
 * 
* Redistribution and use in source and binary forms, with or without modification,
* are permitted (subject to the limitations in the disclaimer below) provided
*  that the following conditions are met:
*
* o Redistributions of source code must retain the above copyright notice, this list
*   of conditions and the following disclaimer.
*
* o Redistributions in binary form must reproduce the above copyright notice, this
*   list of conditions and the following disclaimer in the documentation and/or
*   other materials provided with the distribution.
*
* o Neither the name of the copyright holder nor the names of its
*   contributors may be used to endorse or promote products derived from this
*   software without specific prior written permission.
*
* NO EXPRESS OR IMPLIED LICENSES TO ANY PARTY'S PATENT RIGHTS ARE GRANTED BY THIS LICENSE.
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
* ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
* ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
* ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
* SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#include "fsl_device_registers.h"
#include "fsl_debug_console.h"
#include "uart_kw40_transfer.h"
#include "screens_resources.h"
#include "fsl_psp27801.h"
#include "clock_config.h"
#include "pin_mux.h"
#include "board.h"
/*******************************************************************************
 * Definitions
 ******************************************************************************/


/*******************************************************************************
 * Prototypes
 ******************************************************************************/

/*******************************************************************************
 * Variables
 ******************************************************************************/
extern volatile touch_type_t pressedTouch;
oled_dynamic_area_t splashArea = {.xCrd = 0, .yCrd = 0};
/*******************************************************************************
 * Code
 ******************************************************************************/


/*!
 * @brief Main function
 */
int main(void)
{
    BOARD_InitPins();
    BOARD_BootClockRUN();
    BOARD_InitDebugConsole();

    /* Initialize the timer for delay function */
    Timer_Init();

    /* Initialize the KW40 */
    KW40_UART_Init();

    PRINTF("This is hexiwear relay click demo!\r\n");
    PRINTF(
        "Please Press the left button to toggle the REALY1 and press the right button to toggle the RELAY2!\r\n\r\n");

    /* Initialize the RELAY1 and REALY2 pins */
    gpio_pin_config_t Relay_Config = {kGPIO_DigitalOutput, 0};
    GPIO_PinInit(BOARD_RELAY1_GPIO, BOARD_RELAY1_PIN, &Relay_Config);
    GPIO_PinInit(BOARD_RELAY2_GPIO, BOARD_RELAY2_PIN, &Relay_Config);

    /* Initialize the GPIO and DSPI for OLED transfer */
    OLED_Hardware_Init();
    /* Initialize the OLED and set dynamic area */
    OLED_Init();
    OLED_GetImageDimensions(&(splashArea.width), &(splashArea.height), hexiwear_logo_bmp);
    OLED_SetDynamicArea(&splashArea);

    /* Draw the relay logo image on OLED screen */
    OLED_DrawImage(relay_logo_bmp);

    while (1)
    {
        if (touch_invalid != pressedTouch)
        {
            switch (pressedTouch)
            {
                case touch_left:
                {
                    PRINTF("RELAY1 has been toggled!\r\n");
                    GPIO_PortToggle(BOARD_RELAY1_GPIO, 1U << BOARD_RELAY1_PIN);
                    break;
                }
                case touch_right:
                {
                    PRINTF("RELAY2 has been toggled!\r\n");
                    GPIO_PortToggle(BOARD_RELAY2_GPIO, 1U << BOARD_RELAY2_PIN);
                    break;
                }
                default:
                {
                    break;
                }
            }
            pressedTouch = touch_invalid;
        }
    }
}
