/*
 * The Clear BSD License
 * Copyright (c) 2017, NXP Semiconductors, Inc.
 * All rights reserved.
 *
 * 
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted (subject to the limitations in the disclaimer below) provided
 *  that the following conditions are met:
 *
 * o Redistributions of source code must retain the above copyright notice, this list
 *   of conditions and the following disclaimer.
 *
 * o Redistributions in binary form must reproduce the above copyright notice, this
 *   list of conditions and the following disclaimer in the documentation and/or
 *   other materials provided with the distribution.
 *
 * o Neither the name of the copyright holder nor the names of its
 *   contributors may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * NO EXPRESS OR IMPLIED LICENSES TO ANY PARTY'S PATENT RIGHTS ARE GRANTED BY THIS LICENSE.
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "fsl_debug_console.h"
#include "fsl_mpl3115a2.h"
#include "board.h"
#include "math.h"
#include "screens_resources.h"
#include "fsl_common.h"
#include "pin_mux.h"
#include "fsl_gpio.h"
#include "fsl_port.h"
/*******************************************************************************
 * Definitions
 ******************************************************************************/

/*******************************************************************************
 * Prototypes
 ******************************************************************************/
void BOARD_I2C_ReleaseBus(void);

/*******************************************************************************
 * Variables
 ******************************************************************************/
oled_dynamic_area_t splashArea = {.xCrd = 0, .yCrd = 0};
mpl_handle_t mplHandle;

/*******************************************************************************
 * Code
 ******************************************************************************/

static void i2c_release_bus_delay(void)
{
    uint32_t i = 0;
    for (i = 0; i < I2C_RELEASE_BUS_COUNT; i++)
    {
        __NOP();
    }
}

void BOARD_I2C_ReleaseBus(void)
{
    uint8_t i = 0;
    gpio_pin_config_t pin_config;
    port_pin_config_t i2c_pin_config = {0};

    /* Config pin mux as gpio */
    i2c_pin_config.pullSelect = kPORT_PullUp;
    i2c_pin_config.mux = kPORT_MuxAsGpio;

    pin_config.pinDirection = kGPIO_DigitalOutput;
    pin_config.outputLogic = 1U;
    PORT_SetPinConfig(PRESSURE_I2C_RELEASE_SCL_PORT, PRESSURE_I2C_RELEASE_SCL_PIN, &i2c_pin_config);
    PORT_SetPinConfig(PRESSURE_I2C_RELEASE_SDA_PORT, PRESSURE_I2C_RELEASE_SDA_PIN, &i2c_pin_config);

    GPIO_PinInit(PRESSURE_I2C_RELEASE_SCL_GPIO, PRESSURE_I2C_RELEASE_SCL_PIN, &pin_config);
    GPIO_PinInit(PRESSURE_I2C_RELEASE_SDA_GPIO, PRESSURE_I2C_RELEASE_SDA_PIN, &pin_config);

    /* Drive SDA low first to simulate a start */
    GPIO_PinWrite(PRESSURE_I2C_RELEASE_SDA_GPIO, PRESSURE_I2C_RELEASE_SDA_PIN, 0U);
    i2c_release_bus_delay();

    /* Send 9 pulses on SCL and keep SDA high */
    for (i = 0; i < 9; i++)
    {
        GPIO_PinWrite(PRESSURE_I2C_RELEASE_SCL_GPIO, PRESSURE_I2C_RELEASE_SCL_PIN, 0U);
        i2c_release_bus_delay();

        GPIO_PinWrite(PRESSURE_I2C_RELEASE_SDA_GPIO, PRESSURE_I2C_RELEASE_SDA_PIN, 1U);
        i2c_release_bus_delay();

        GPIO_PinWrite(PRESSURE_I2C_RELEASE_SCL_GPIO, PRESSURE_I2C_RELEASE_SCL_PIN, 1U);
        i2c_release_bus_delay();
        i2c_release_bus_delay();
    }

    /* Send stop */
    GPIO_PinWrite(PRESSURE_I2C_RELEASE_SCL_GPIO, PRESSURE_I2C_RELEASE_SCL_PIN, 0U);
    i2c_release_bus_delay();

    GPIO_PinWrite(PRESSURE_I2C_RELEASE_SDA_GPIO, PRESSURE_I2C_RELEASE_SDA_PIN, 0U);
    i2c_release_bus_delay();

    GPIO_PinWrite(PRESSURE_I2C_RELEASE_SCL_GPIO, PRESSURE_I2C_RELEASE_SCL_PIN, 1U);
    i2c_release_bus_delay();

    GPIO_PinWrite(PRESSURE_I2C_RELEASE_SDA_GPIO, PRESSURE_I2C_RELEASE_SDA_PIN, 1U);
    i2c_release_bus_delay();
}

int main(void)
{
    mpl_config_t mplConfig;
    float pressureData = 0;

    /* Board Hardware init: pin mux, clock, debug console. */
    BOARD_InitPins();
    BOARD_BootClockRUN();
    BOARD_I2C_ReleaseBus();
    BOARD_InitI2CPins();
    ;
    BOARD_InitDebugConsole();
    /* Board I2C initialization for sensor. */
    BOARD_Pressure_I2C_Init();

    PRINTF("This is HEXWEAR pressure sensor(MPL3115A2) example.\r\n");
    PRINTF("The debug console will print the current pressure data every 2 second.\r\n");

    /* Initialize the timer for delay function */
    Timer_Init();
    /* Initialize the GPIO and DSPI for OLED transfer */
    OLED_Hardware_Init();
    OLED_Init();
    OLED_GetImageDimensions(&(splashArea.width), &(splashArea.height), hexiwear_logo_bmp);
    OLED_SetDynamicArea(&splashArea);
    OLED_DrawImage(hexiwear_logo_bmp);

    /* Init the pressure sensor(MPL3115A2). */
    mplConfig.I2C_SendFunc = BOARD_Pressure_I2C_Send;
    mplConfig.I2C_ReceiveFunc = BOARD_Pressure_I2C_Receive;
    mplConfig.mode = kMPL_modePressure;
    mplConfig.overSample = kMPL_overSample0;
    if (kStatus_MPL_Success != MPL_Init(&mplHandle, &mplConfig))
    {
        PRINTF("Error occurred when initialize the pressure sensor.\r\n");
        return -1;
    }
    else
    {
        PRINTF("\r\nPressure sensor initialized successfully.");
        PRINTF("\r\nPress any key to start read the pressure data...\r\n\r\n");
        GETCHAR();
    }

    /* Infinite loops */
    for (;;)
    {
        Timer_Delay_ms(2000);
        if (kStatus_MPL_Success != MPL_ReadPressure(&mplHandle, &pressureData))
        {
            PRINTF("Error occurred when read data from sensor!\r\n");
        }
        else
        {
            /* Translate pressure to kPa, the origin value is Pa. */
            pressureData = (float)pressureData / 1000;
            PRINTF("  The current pressure value is: %.2f kPa.\r\n", pressureData);
        }
    }
}
