/*
 * The Clear BSD License
 * Copyright (c) 2016, NXP Semiconductors, Inc.
* All rights reserved.
*
 * 
* Redistribution and use in source and binary forms, with or without modification,
* are permitted (subject to the limitations in the disclaimer below) provided
*  that the following conditions are met:
*
* o Redistributions of source code must retain the above copyright notice, this list
*   of conditions and the following disclaimer.
*
* o Redistributions in binary form must reproduce the above copyright notice, this
*   list of conditions and the following disclaimer in the documentation and/or
*   other materials provided with the distribution.
*
* o Neither the name of the copyright holder nor the names of its
*   contributors may be used to endorse or promote products derived from this
*   software without specific prior written permission.
*
* NO EXPRESS OR IMPLIED LICENSES TO ANY PARTY'S PATENT RIGHTS ARE GRANTED BY THIS LICENSE.
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
* ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
* ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
* ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
* SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#include "fsl_device_registers.h"
#include "fsl_debug_console.h"
#include "screens_resources.h"
#include "fsl_psp27801.h"
#include "clock_config.h"
#include "fsl_port.h"
#include "pin_mux.h"
#include "board.h"

/*******************************************************************************
 * Definitions
 ******************************************************************************/


/*******************************************************************************
 * Prototypes
 ******************************************************************************/

/*******************************************************************************
 * Variables
 ******************************************************************************/
volatile uint8_t isMotionDetected = 0U;
oled_dynamic_area_t splashArea = {.xCrd = 0, .yCrd = 0};
/*******************************************************************************
 * Code
 ******************************************************************************/

void BOARD_MOTION_IRQ_HANDLER(void)
{
    /* Clear external interrupt flag. */
    GPIO_PortClearInterruptFlags(BOARD_MOTION_GPIO, 1U << BOARD_MOTION_GPIO_PIN);
    /* Check state of motiondetected. */
    if (1 == GPIO_PinRead(BOARD_MOTION_GPIO, BOARD_MOTION_GPIO_PIN))
    {
        isMotionDetected = 1;
    }
    else
    {
        isMotionDetected = 2;
    }
    /* Add for ARM errata 838869, affects Cortex-M4, Cortex-M4F Store immediate overlapping
      exception return operation might vector to incorrect interrupt */
#if defined __CORTEX_M && (__CORTEX_M == 4U)
    __DSB();
#endif
}

/*!
 * @brief Main function
 */
int main(void)
{
    /* Define the init structure for the input motion pin */
    gpio_pin_config_t motion_pin_config = {kGPIO_DigitalInput, 0};
    gpio_pin_config_t motion_enable_pin_config = {kGPIO_DigitalOutput, 1};

    BOARD_InitPins();
    BOARD_BootClockRUN();
    BOARD_InitDebugConsole();

    /* Initialize the timer for delay function */
    Timer_Init();

    PRINTF("This is hexiwear motion click demos!\r\n");
    PRINTF("Please close to the motion sensor by your hand to trigger a motion detection.\r\n");

    /* Init input motion GPIO. */
    PORT_SetPinInterruptConfig(BOARD_MOTION_PORT, BOARD_MOTION_GPIO_PIN, kPORT_InterruptEitherEdge);
    EnableIRQ(BOARD_MOTION_PORT_IRQn);
    GPIO_PinInit(BOARD_MOTION_GPIO, BOARD_MOTION_GPIO_PIN, &motion_pin_config);
    GPIO_PinInit(BOARD_MOTION_ENABLE_GPIO, BOARD_MOTION_ENABLE_GPIO_PIN, &motion_enable_pin_config);
    /* Enable the motion */
    GPIO_PortSet(BOARD_MOTION_ENABLE_GPIO, 1 << BOARD_MOTION_ENABLE_GPIO_PIN);
    /* Initialize OLED */
    OLED_Hardware_Init();
    OLED_Init();
    OLED_GetImageDimensions(&(splashArea.width), &(splashArea.height), hexiwear_logo_bmp);
    OLED_SetDynamicArea(&splashArea);

    OLED_DrawImage(motion_none_bmp);

    while (1)
    {
        if (1U == isMotionDetected)
        {
            PRINTF("Motion detected!\r\n");
            OLED_DrawImage(motion_detected_bmp);
            isMotionDetected = 0U;
        }
        else if (2U == isMotionDetected)
        {
            PRINTF("No motion detected!\r\n");
            OLED_DrawImage(motion_none_bmp);
            isMotionDetected = 0U;
        }
    }
}
