Overview
========
The hexiwear_motion_click demo application provides a sanity demo for users to trigger a motion detection by.
Then the sensor will detect it and the oled will draw a image on the oled screen. The purpose of this demo is to 
show how to detect the trigger from external sensor and draw a image on the oled screen, and to provide a simple
project for debugging and further development. 

Toolchain supported
===================
- Keil MDK 5.24a
- IAR embedded Workbench 8.22.2
- GCC ARM Embedded 7-2017-q4-major
- MCUXpresso10.2.0

Hardware requirements
=====================
- Mini/micro USB cable
- Hexiwear Main board/Hexiwear Docking Station board/MOTION click board
- Personal Computer

Board settings
==============
Please plug the Hexiwear Main board to the Hexiwear Docking Station board and plug the MOTION click board to 
MIKROBUS2 on Hexiwear Docking Station board.

Prepare the Demo
================
1.  Connect a USB cable between the host PC and the OpenSDA USB port on the target board.
2.  Open a serial terminal with the following settings:
    - 115200 baud rate
    - 8 data bits
    - No parity
    - One stop bit
    - No flow control
3.  Download the program to the target board.
4.  Either press the reset button on your board or launch the debugger in your IDE to begin running the demo.

Running the demo
================
When a motion is detected by the sensor, the oled will diaplay a motion_detected image.
The log below shows the output of the hexiwear_motion_click demo in the terminal window:
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
This is hexiwear motion click demos!
Please close to the motion sensor by your hand to trigger a motion detection.
Motion detected!
No motion detected!
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Customization options
=====================

