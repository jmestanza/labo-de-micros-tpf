/*
 * The Clear BSD License
 * Copyright (c) 2017, NXP Semiconductors, Inc.
 * All rights reserved.
 *
 * 
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted (subject to the limitations in the disclaimer below) provided
 *  that the following conditions are met:
 *
 * o Redistributions of source code must retain the above copyright notice, this list
 *   of conditions and the following disclaimer.
 *
 * o Redistributions in binary form must reproduce the above copyright notice, this
 *   list of conditions and the following disclaimer in the documentation and/or
 *   other materials provided with the distribution.
 *
 * o Neither the name of the copyright holder nor the names of its
 *   contributors may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * NO EXPRESS OR IMPLIED LICENSES TO ANY PARTY'S PATENT RIGHTS ARE GRANTED BY THIS LICENSE.
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "fsl_debug_console.h"
#include "fsl_tsl2561.h"
#include "board.h"
#include "math.h"
#include "screens_resources.h"
#include "fsl_common.h"
#include "pin_mux.h"
#include "fsl_gpio.h"
#include "fsl_port.h"
/*******************************************************************************
 * Definitions
 ******************************************************************************/

/*******************************************************************************
 * Prototypes
 ******************************************************************************/
void BOARD_I2C_ReleaseBus(void);
void BOARD_PowerOnLightSensor(void);

/*******************************************************************************
 * Variables
 ******************************************************************************/
oled_dynamic_area_t splashArea = {.xCrd = 0, .yCrd = 0};
tsl_handle_t tslHandle;

/*******************************************************************************
 * Code
 ******************************************************************************/

void BOARD_PowerOnLightSensor(void)
{
    gpio_pin_config_t pin_config;

    pin_config.pinDirection = kGPIO_DigitalOutput;
    pin_config.outputLogic = 0U;
    GPIO_PinInit(AMBIENT_LIGHT_POWER_GPIO, AMBIENT_LIGHT_POWER_GPIO_PIN, &pin_config);
}

static void i2c_release_bus_delay(void)
{
    uint32_t i = 0;
    for (i = 0; i < AMBIENT_LIGHT_I2C_RELEASE_BUS_COUNT; i++)
    {
        __NOP();
    }
}

void BOARD_I2C_ReleaseBus(void)
{
    uint8_t i = 0;
    gpio_pin_config_t pin_config;
    port_pin_config_t i2c_pin_config = {0};

    /* Config pin mux as gpio */
    i2c_pin_config.pullSelect = kPORT_PullUp;
    i2c_pin_config.mux = kPORT_MuxAsGpio;

    pin_config.pinDirection = kGPIO_DigitalOutput;
    pin_config.outputLogic = 1U;
    PORT_SetPinConfig(AMBIENT_LIGHT_I2C_RELEASE_SCL_PORT, AMBIENT_LIGHT_I2C_RELEASE_SCL_PIN, &i2c_pin_config);
    PORT_SetPinConfig(AMBIENT_LIGHT_I2C_RELEASE_SDA_PORT, AMBIENT_LIGHT_I2C_RELEASE_SDA_PIN, &i2c_pin_config);

    GPIO_PinInit(AMBIENT_LIGHT_I2C_RELEASE_SCL_GPIO, AMBIENT_LIGHT_I2C_RELEASE_SCL_PIN, &pin_config);
    GPIO_PinInit(AMBIENT_LIGHT_I2C_RELEASE_SDA_GPIO, AMBIENT_LIGHT_I2C_RELEASE_SDA_PIN, &pin_config);

    /* Drive SDA low first to simulate a start */
    GPIO_PinWrite(AMBIENT_LIGHT_I2C_RELEASE_SDA_GPIO, AMBIENT_LIGHT_I2C_RELEASE_SDA_PIN, 0U);
    i2c_release_bus_delay();

    /* Send 9 pulses on SCL and keep SDA high */
    for (i = 0; i < 9; i++)
    {
        GPIO_PinWrite(AMBIENT_LIGHT_I2C_RELEASE_SCL_GPIO, AMBIENT_LIGHT_I2C_RELEASE_SCL_PIN, 0U);
        i2c_release_bus_delay();

        GPIO_PinWrite(AMBIENT_LIGHT_I2C_RELEASE_SDA_GPIO, AMBIENT_LIGHT_I2C_RELEASE_SDA_PIN, 1U);
        i2c_release_bus_delay();

        GPIO_PinWrite(AMBIENT_LIGHT_I2C_RELEASE_SCL_GPIO, AMBIENT_LIGHT_I2C_RELEASE_SCL_PIN, 1U);
        i2c_release_bus_delay();
        i2c_release_bus_delay();
    }

    /* Send stop */
    GPIO_PinWrite(AMBIENT_LIGHT_I2C_RELEASE_SCL_GPIO, AMBIENT_LIGHT_I2C_RELEASE_SCL_PIN, 0U);
    i2c_release_bus_delay();

    GPIO_PinWrite(AMBIENT_LIGHT_I2C_RELEASE_SDA_GPIO, AMBIENT_LIGHT_I2C_RELEASE_SDA_PIN, 0U);
    i2c_release_bus_delay();

    GPIO_PinWrite(AMBIENT_LIGHT_I2C_RELEASE_SCL_GPIO, AMBIENT_LIGHT_I2C_RELEASE_SCL_PIN, 1U);
    i2c_release_bus_delay();

    GPIO_PinWrite(AMBIENT_LIGHT_I2C_RELEASE_SDA_GPIO, AMBIENT_LIGHT_I2C_RELEASE_SDA_PIN, 1U);
    i2c_release_bus_delay();
}

int main(void)
{
    tsl_config_t tslConfig;
    uint32_t lightData = 0U;

    BOARD_InitPins();
    BOARD_BootClockRUN();
    BOARD_I2C_ReleaseBus();
    BOARD_InitI2CPins();
    BOARD_InitDebugConsole();

    BOARD_PowerOnLightSensor();
    BOARD_Ambientlight_I2C_Init();
    PRINTF("This is HEXWEAR ambient light sensor(TSL2561) example.\r\n");
    PRINTF("The debug console will print the current ambient light data every 2 second.\r\n");

    /* Initialize the timer for delay function */
    Timer_Init();
    /* Initialize the GPIO and DSPI for OLED transfer */
    OLED_Hardware_Init();
    OLED_Init();
    OLED_GetImageDimensions(&(splashArea.width), &(splashArea.height), hexiwear_logo_bmp);
    OLED_SetDynamicArea(&splashArea);
    OLED_DrawImage(hexiwear_logo_bmp);

    /* Initialize the ambient light sensor (TSL2561). */
    tslConfig.I2C_SendFunc = BOARD_Ambientlight_I2C_Send;
    tslConfig.I2C_ReceiveFunc = BOARD_Ambientlight_I2C_Receive;
    tslConfig.slaveAddress = 0x29;
    tslConfig.gain = kTSL_GainX0;
    tslConfig.timing = kTSL_IntergrationTime13ms;
    if (kStatus_TSL_Success != TSL_Init(&tslHandle, &tslConfig))
    {
        PRINTF("Error occurred when initialize the ambient light sensor.\r\n");
        return -1;
    }
    else
    {
        PRINTF("\r\n  Initialize the ambient light sensor successfully.\r\n");
        PRINTF("\r\nPress any key to start read the pressure data...\r\n\r\n");
        GETCHAR();
    }

    /* Infinite loops */
    for (;;)
    {
        Timer_Delay_ms(2000);
        if (kStatus_TSL_Success != TSL_GetAmbiLuxValue(&tslHandle, &lightData))
        {
            PRINTF("Error occurred when read data from sensor!\r\n");
        }
        else
        {
            PRINTF("  The current light value is: %d Lux.\r\n", lightData);
        }
    }
}
