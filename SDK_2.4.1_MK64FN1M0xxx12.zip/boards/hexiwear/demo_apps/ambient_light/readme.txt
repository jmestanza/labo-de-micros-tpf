Overview
========
The ambient light demo application demonstrates the use of the TSL2561 sensor. The ambient light
value can be read from this sensor.

Toolchain supported
===================
- Keil MDK 5.24a
- IAR embedded Workbench 8.22.2
- GCC ARM Embedded 7-2017-q4-major
- MCUXpresso10.2.0

Hardware requirements
=====================
- Mini/micro USB cable
- Hexiwear main board
- Personal Computer

Board settings
==============
No special settings are required.
Please note that: the light sensor is in the internal of hexiwear board. The light value may too small
to read, so the return data is zero. You can remove the lid from the board, the sensor can receive more
light, then data will be larger to read, and it's better to use light to illuminate the sensor.

Prepare the Demo
================
1.  Connect a USB cable between the host PC and the OpenSDA USB port on the target board.
2.  Open a serial terminal with the following settings:
    - 115200 baud rate
    - 8 data bits
    - No parity
    - One stop bit
    - No flow control
3.  Download the program to the target board.
4.  Either press the reset button on your board or launch the debugger in your IDE to begin running the demo.

Running the demo
================
When the demo runs successfully, you can see the information below printed to the terminal. 
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
This is HEXWEAR ambient light sensor(TSL2561) example.
The debug console will print the current ambient light data every 2 second.

  Initialize the ambient light sensor successfully.

Press any key to start read the pressure data...

  The current light value is: 6 Lux.
  The current light value is: 6 Lux.
  The current light value is: 7 Lux.
  The current light value is: 107 Lux.
  The current light value is: 143 Lux.
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Customization options
=====================

